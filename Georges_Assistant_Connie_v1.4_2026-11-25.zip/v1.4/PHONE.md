# George's Assistant on your phone — November 17, 2026
Owner and creator: George Wederski

George's Assistant v1.1 Upgraded is phone-friendly: big tap targets,
single-column layout on a phone, tabs you swipe sideways, tables
that scroll sideways inside their panel, full-width forms, and it
can be added to your phone's home screen like an app. It is **not**
a native app in the Play Store — there is no app-store download.
There are two ways to use it on your phone, below.

## What changed for phones
- Buttons and inputs are at least 44px tall, so they are easy to
  tap one-handed. The ten tabs sit in one row you swipe across.
- Forms go full-width and single-column under ~700px wide. Text
  boxes use 16px text so the phone does not zoom in when you tap
  them. The chat box grows to about half the screen.
- Home-screen support (PWA): `web/manifest.webmanifest` with the
  name George's Assistant, navy theme, and 192/512 icons, plus
  `web/sw.js`, a service worker that caches only the app shell
  (pages, CSS, JS, icons) so the app opens even with a flaky
  connection. It **never** caches API responses, sign-in, records
  or the database — those always go to the server, so your records
  still need the server (route A) or the hosted demo (route B).
- To add it to your home screen: open the app in your phone
  browser, then use the browser menu → "Add to Home screen"
  (Chrome on Android) or Share → "Add to Home Screen" (Safari
  on iPhone). It will open full-screen like an app. There is also
  an install button in the app itself: **Settings → "Put Connie
  on my phone" → "Add Connie to my home screen"** (Android/Chrome;
  iPhone does not offer that button, so use Share instead).
  **Honest note:** the home-screen icon alone does not run Connie —
  her server still has to be running (Route A, same Wi-Fi, or a
  hosted server). If the server is off, the app opens but your
  records will not load. This is NOT a Play Store app.

## Route A — Same Wi-Fi (the real app, with your real records)
This is the full app, with your own sign-in and records. It only
works while the server is running on your computer, and only on
your home Wi-Fi — not on the open internet.

1. On your **computer**, find its address on your Wi-Fi:
   - Windows: press Windows key + R, type `cmd`, press Enter,
     type `ipconfig`, look for "IPv4 Address" — it looks like
     `192.168.1.23`.
   - Mac: System Settings → Wi-Fi → click your network → the IP
     address is shown there.
   Write that number down. It changes sometimes; if the phone
   stops reaching the bot, check it again.
2. On your computer, open a terminal in the bot folder and run:
   ```
   HOST=0.0.0.0 PORT=8765 python3 server.py
   ```
   (On Windows use `set HOST=0.0.0.0` first, then
   `python server.py`.) Leave that window open while you use it.
3. On your **phone**, connected to the same Wi-Fi, open the
   browser and go to:
   ```
   http://<your computer's IP>:8765
   ```
   For example, if the IP is 192.168.1.23, go to
   `http://192.168.1.23:8765`. Sign in with the same username
   and password you use on the computer — your records are the
   same ones.
4. When you are done, close the server on the computer
   (Ctrl+C in that window). **Home Wi-Fi only.** Do not open
   that port to the internet — the app is not ready for that
   (see HOSTING.md: it needs a host, a web address, HTTPS and a
   security review first).

## Route B — Hosted phone demo (no computer needed)
A hosted demo of the bot, made for trying it on a phone:

- Hosted demo: artifact **people-s-bot-phone-demo** — open it from the
  demo card in the chat (card: `web-artifact-build-completed-7f820e66-c055-4364-bd2c-21afeef1d2a4`).
  It was built and audit-checked 2026-11-16: banner says demo, 11 tabs,
  sample assistant, Integrations hub, store with "Not taking payment yet".

Open it on your phone and walk through the screens. It is a
**demo only**: the banner at the top says so. It uses sample data
only (customer "Smith", an invoice for $150.00 for fixing a leak,
and similar), stored in that phone browser only. There are no real
records, no sign-in to your real bot, no live AI, no payments and
no calls. Anything you type in the demo stays in that browser and
does not reach your real bot. Use it to see how the bot looks and
feels on a phone; use Route A for your real records.

## What the bot can do on your phone
- **George's Assistant Assistant (do-anything front door):** type or
  dictate any request in plain words. It first tries to do it in
  the app — search your saved records, money totals, what's on
  today, add a task or reminder, start an invoice or customer
  with the details filled in, draft a product description, plan
  or list, work out numbers — and only then asks the live AI.
  Drafts are drafts: nothing is sent, charged, filed, published
  or ordered without your approval. The in-bot assistant is
  called the **George's Assistant Assistant**. It is **not Remy** —
  Remy is George's personal assistant in the Muse app, for
  George only, and customers cannot talk to Remy through the bot.
- **Which bot answers?** In the Assistant, pick ChatGPT (OpenAI)
  or Claude (Anthropic) for live chat. Each shows "Available"
  only when its key+model are set on the server; otherwise
  "Not connected — needs your key". Any signed-in user of the bot
  can use whichever bot George has connected; each user only sees
  their own records. This is not open to the public — sign-up is
  as configured, and the bot is not on the internet until George
  approves hosting.
- **Integrations / Crosswalk:** the hub for plugging other bots,
  tools and apps into George's Assistant. Every connector is a slot
  with a name, what it adds, what it needs, its status, and an
  enable/disable switch. Slots: Crosswalk itself, Claude,
  ChatGPT, Gemini (not wired in — the server only supports
  Anthropic and OpenAI), Google Calendar, Gmail, Stripe, phone,
  bank feeds, tax filing, Remy/Muse, plus "Add another app or
  bot" custom slots you can name yourself. Only Anthropic and
  OpenAI report Connected, from the server's real status. Every
  other slot is Not connected — or "Needs your key" once you
  switch it on — until that service's own account/key is supplied
  on the server. Switching a slot on never connects it.
  Crosswalk itself is Not connected: the signup started Nov 6,
  2026 as "Rumi (Muse)" was never finished and no Crosswalk key
  is saved; there is no Crosswalk connector to install.
- **Talk to Remy (George only):** there is **no key for Remy** —
  Remy lives in the Muse app, and no key can be made for it.
  Open Muse and talk to Remy there, by text or voice call, and
  Remy can help with this bot, your records, your trading desk,
  Stripe / Whop / Etsy steps, and anything else. Customers using
  George's Assistant cannot talk to George's Remy, and George's private
  records and money are never shared with them. No Remy key was
  created, hardcoded or displayed anywhere.

## What is still NOT true on the phone
- It is not a native app in the Play Store, and it does not sync
  to your phone by itself. Route A only works while the server
  runs on your computer and your phone is on the same Wi-Fi.
  Route B is a demo with sample data only.
- No live AI until George sets a server-side Anthropic or OpenAI
  key. With no key, live chat says "AI is not connected yet"
  (tested: 503), and the Assistant still does its in-app jobs.
- No live payments (Stripe), phone calls, bank feeds, calendar
  sync, email sending or tax filing — all labelled "Not
  connected" in the app.
- No live Remy inside the bot, no Crosswalk connection, no
  Gemini. No key for any of these was invented.

## Verification (2026-11-16)
- Server tests: **10/10 pass**, including CRUD for all 18 record
  kinds (now including `connectors`), per-user isolation, and the
  provider-picker test (picks Anthropic when asked, defaults to
  OpenAI, refuses Gemini with 503).
- Offline Assistant harness (Node): **21/21 pass** — totals,
  maths, record search, today's appointments, saving a reminder,
  invoice/customer drafts, product draft, help list, Crosswalk
  routing, Remy "no key" answer, provider picker, connector
  catalog.
- Live run: server started; all 10 static files returned 200
  with correct content types (including the manifest as
  `application/manifest+json`); signup + login worked; created a
  customer, invoice, Published product, two connector records
  and a task; the public store listed the product with
  `has_payment: false`; AI chat with no key returned 503 with no
  provider, with provider "openai", and with provider "gemini";
  `/api/status` reported `providers: []`; backup export returned
  all 6 records.
- **Not verified in a real browser:** a phone-width screenshot
  was not possible — the VM's headless Chrome refuses to start
  ("Hatch WebGL domain policy is required for browser startup").
  Phone layout was verified by the CSS/media-query audit, the
  curl checks above and the harness. Please check it on a real
  phone with the steps above and say if anything looks wrong.
  The service worker was syntax-checked and is served correctly;
  its first real registration happens on a phone.

<small>© 2026 George Wederski. All rights reserved. No part of this book/app may be copied, reproduced, or shared without written permission from George Wederski.</small>
