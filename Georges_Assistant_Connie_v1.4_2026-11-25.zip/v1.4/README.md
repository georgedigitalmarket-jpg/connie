# George's Assistant — Connie (personal copy)
Owner: **George Wederski**
Assistant name: **Connie** — she speaks in a **girl's voice by default**.

This is George's own personal assistant. It is **NOT for sale, has no
customers, no plans, no prices, and no storefront**. It is a personal
copy of People's Bot v1.1 Upgraded (2026-11-17), rebranded for George
alone. The source folder
`~/workspace/user/files/peoples-bot-v1-1-mobile/` was not changed.
The old `previous_versions/` folders were not copied — this copy
branches from the latest active build only.


## NEW in v1.2 — Connie Plus (21 November 2026)
Everything George asked for on 20–21 Nov 2026. Open the new **Today** tab first.

- **"Hey Connie" — hands-free.** Turn it on with the 🎙️ button (bottom right) or on the Assistant screen. Say *"Hey Connie, what's on today?"*, or just *"Hey Connie"* and wait for *"Yes, George?"* She answers out loud. It works while Connie is open on screen. Phones turn the microphone off when the screen locks, so it can't listen 24/7 in your pocket.
- **Morning briefing.** Tap *"Give me my briefing"* on Today, or say *"good morning"*. She covers today's calendar and appointments, reminders, tasks, money this month, what's owed to you, Stripe sales, unread email, bills due and anything Business Watch spotted. If you open Connie in the morning, she offers to read it (tap once, because phones only allow speech after a tap).
- **Reminders that really remind.** *"Remind me to call Smith tomorrow at 3pm"*, *"in 20 minutes check the oven"*, *"pay rent every month"*, *"every Monday at 9"*. She speaks up and pops a notice when one is due (while open), with Done and Snooze. Repeats roll forward on their own.
- **Business Watch.** Overdue invoices, invoices due soon, out of stock or low stock, late tasks, urgent calls with no follow-up, spending ahead of income, unusual expenses, no income for 14 days, bills due or late, Stripe failed payments and disputes. She only points things out. She changes nothing.
- **Each business, separate.** Every income, expense, invoice and bill can be tagged with its business: George's Little Handy Books, ALI, People's Bot, GDP, Personal, or any new one. She shows money in, money out, profit or loss, and a tax set-aside for each, plus all of them together. Ask *"how much am I making?"*.
- **Bills — she asks first, always.** Bills under your name are listed with due dates and warnings. She asks *"Can I pay this?"* and never pays on her own. No bank is connected, so after your yes you pay it from your bank, then tap *Mark paid* and she books it to the right business. Saying yes needs your voice plus passcode once those are set.
- **Read a receipt.** Take a photo and the brain reads the store, date, total, tax, category and items into a draft expense, or a bill. You check it and save it. The photo is not kept. This needs an AI key.
- **Make products and marketing.** Pick a business, then choose: what do customers want, a new digital product idea plus draft, 3 ads (they end with "Created by George, made with the influence of Claude and Muse"), a week of posts, a 30-day marketing plan, or how this business is doing. These are drafts only. She never publishes, posts, advertises or spends on her own.
- **All in One brain.** The new default in *"Which bot answers?"*. Fable 5.2, Opus 5.5 and GPT-6.2 Astra all answer at once, then Fable merges them into one best answer. One `ANTHROPIC_API_KEY` runs two of the three (Fable and Opus). GPT-6.2 Astra joins when `OPENAI_API_KEY` is also set, because OpenAI is a different company and needs its own key. Each answer costs about 3–4 times a single-brain answer.
- **Memory upgrades: unlimited, never stops learning.**
  - **No cap:** learned notes don't count toward the record limit.
  - **Sorted by topic:** every note gets a topic (Customers, Money, Business, Home & family, Preferences, Other).
  - **Pin and search:** pin the important ones, and search them all on the Learning tab.
  - **Smart recall:** each question gets the pinned notes plus the most relevant notes, so memory can grow forever and stay sharp.
  - **Notices things:** when you mention something like *"my truck is a 2019 F-150"*, she asks *"Want me to remember this?"* and only saves it if you say yes.
  - **Private:** only you can see it.
- **Offline.** Your last-loaded records stay on your phone. Changes you make with no signal are sent when you're back online.
- **Nightly backup to Google Drive.** Every night after 2 am Wyoming time, your records go to a *"Connie Backups"* folder in your Drive, and the last 14 copies are also kept on Connie's own disk. There's also a *Back up now* button under Integrations.
- **Live connectors (Integrations tab).** Each one works when its key is set on the server:
  - **Stripe:** sales, balance, failed payments, disputes. Read-only, using a restricted key.
  - **Google Calendar:** read your calendar, and add an event after your yes.
  - **Google Drive:** find files by name, and store the backups.
  - **Email:** unread mail shows in your briefing. She sends only after your yes, plus your voice and passcode.
- **Fixed:**
  - Connie's own security policy was blocking every inline button and form, so "Add" on the record screens, Edit/Delete and many buttons silently did nothing. `csp-safe.js` makes them work and keeps the strict policy.
  - "Research to upgrade me" was saving its reply in a format that broke the next live chat. Fixed.
  - Chat history starting with Connie's message was refused by Claude. Fixed.

### Connect Google (one time, about 10 minutes)
1. Go to https://console.cloud.google.com, make a project, and open **APIs & Services → Library**. Turn on **Google Drive API** and **Google Calendar API**.
2. Open **APIs & Services → OAuth consent screen**: choose External, give the app the name "Connie", and add your own Gmail as a test user.
3. Open **Credentials → Create credentials → OAuth client ID** and choose type **Desktop app**. Copy the Client ID and Client secret.
4. On the computer where Connie runs, type `python3 connect_google.py` and paste the two values. Sign in as yourself and press Allow. Then restart `server.py`.

Connie only gets: the files she makes herself (backups), the *names* of your Drive files (not their contents), and your calendar events. To undo it, remove Connie at https://myaccount.google.com/permissions.

### What Connie will NOT do on her own — on purpose
- **Pay a bill, move money, or buy or sell stocks or anything else.** Every one of those waits for your yes. Not even "just once if George isn't around": nobody can know a trade will make money, and one wrong automatic buy can cost real savings. She can watch, explain, paper-trade and suggest.
- **Publish, post, advertise, email or spend** without your yes.
- **Make money from ads by herself.** Ad income only comes from ads on a website or app real people visit, through an ad account in your name (for example Google AdSense on your book store site). It depends on visitors and isn't guaranteed. She can help set that up and write content that brings visitors in.


## Connie — her voice
- **Connie's starting voice is a girl / female voice**: on sign-in
  the app picks the first female voice on George's own device
  (`speechSynthesis` voices) and uses it. She introduces herself
  out loud as Connie: "Hello, George. I'm Connie, your personal
  assistant, in a girl's voice." There is a "Hear Connie say hello"
  button on the Assistant screen.
- **Change it by asking:** "change your voice to a girl voice",
  "use a male voice", "use Samantha's voice", "an Australian girl
  voice", "a Mexican voice" — Connie switches right away and answers
  back in the new voice. Or pick one in Settings — Voice choice
  (tap "Hear it", then "Use this voice").
- Voices come only from the device itself; Connie does not invent a
  voice, and there is no live AI voice model in this build (no AI key
  is set). She never labels a voice by race or ethnicity — only by
  the accent / language name the device gives it.
- **Picking a voice does NOT change voice recognition.** Only
  George's enrolled voice can start jobs.

## What Connie does (all 12 screens)
Assistant (Connie), Today (new in v1.2), Front Desk, Invoices, Money, Inventory, Tasks,
Products & Marketing (George's own drafts only — no storefront),
Personal, Paper Trading (paper only), Learning, Settings, Integrations.
Sign-in with recovery codes, per-user saved records, backup
export/import, audit history.

## Permission first — Connie asks George first, every time
**"I ask first, every time. I only see what you said yes to."**
Before Connie looks at George's records, does a job, or uses a
connected tool, she shows plainly what she wants to do and waits
for George's yes. If he says no, or does not answer, she does
nothing. Access is **George only** — there are no other accounts
or customers on this copy, and nobody else can see George's records.

## Multitasking — on-demand only
Connie can do several jobs at once **when George asks her to**, in
one request. She never starts a job on her own, and nothing runs
in the background unprompted. A job only reads George's own saved
records and works out a summary or a draft. **It never sends,
charges, publishes or deletes anything.**

## Voice recognition — safety feature, not a secure ID
Connie only runs jobs for **George's enrolled voice**, once he
enrols it in Settings with his consent. The browser works out 16
numbers from the sound of his voice and sends only those numbers
to this server — **no audio recording is stored, and no voice is
sent anywhere.** A different voice is not recognised and no job
starts. This is a safety feature, not a secure ID — a recording
could fool it, and a cold or background noise can make it fail.
**Voice recognition alone NEVER authorises** taxes, bank access,
payments, publishing or sending — those still need a separate yes,
every time.

## Learn — Fast Learn, open knowledge, ask first
George said: learn everything, fast — her knowledge is open. So
that is how it works here. In the Assistant, type or say
**"learn this: ..."** for one thing, or **"learn these: ..."** for
several at once — for example "learn these: Smith likes mornings;
the shop opens at 8; paint is in the garage". Connie asks first
(one yes covers the whole list), George says yes, and only then she
saves each one as a learned note in her own records on this server,
and says **"I learned: ..."** back to him for each one, out loud
and in chat. Say no and she saves nothing. Each item in a list is
still saved one at a time, only after his yes — **never without
his yes.**
- **Open knowledge:** the Learning screen shows everything Connie
  learned, with a search box — searchable, and **no cap** on how
  many learned notes she holds (`learned_notes_text()` returns them
  all). Nothing is hidden.
- **Faster than the customer bot:** Connie is allowed **60 AI
  requests per user per hour** — double the customer bot's 30 —
  and **no 5-hour session limit** for George. `/api/health`
  reports `ai_hourly_limit: 60` and `session_limit: "none — no
  5-hour session limit for George"`.
- **Monthly upgrade — free for George:** once a month Connie
  reviews what she learned that month and shows a plain summary
  on the Learning tab — "Show my monthly upgrade" — for example
  "November upgrade: I learned 12 new things", labelled
  "Connie — November 2026 upgrade". **Your upgrades are free.**
  Connie is George's personal bot — he pays nothing for her
  upgrades. There is no price and no payment anywhere in Connie.
  The upgrade is only that summary: it does NOT retrain or change
  the model, does NOT change code by itself, and does NOT go to
  the internet. George approves it ("Yes — apply this monthly
  upgrade") or says no — and if he says no, nothing is saved and
  nothing changes. `GET /api/monthly-upgrade?year=2026&month=11`
  builds the summary; `POST /api/monthly-upgrade` with
  `{"approved": true}` saves one `upgrades` record, with
  `{"approved": false}` saves nothing.
- **Learning is local notes only.** It does NOT retrain the model,
  does NOT change the model, and does NOT go to the internet.
- Learned notes are used in future answers: they are listed on the
  **Learning** screen, shown in the Assistant, and sent with the
  question to the live AI (when a key is set) so it can use them.
- **Forget any time:** each note has a "Forget this" button on the
  Learning screen, plus "Forget everything I learned".
- **Connie refuses to learn or do anything against the law, and
  says why** — for example pretending to be someone else, copying
  someone's voice without their say-so, getting into someone else's
  phone or account, or writing fake reviews. That rule cannot be
  switched off, and the server refuses such a note too (HTTP 400),
  so it cannot be saved around the Assistant.

## Security — voice + passcode, the security blanket
Only George gets into Connie — **voice first, then passcode**,
in that order. Enrol your voice in Settings, then set a passcode
there ("Set my passcode" — you type it yourself, and you also
type your account password to prove it's you).
- **The passcode is never stored in plain text** — only a salted
  hash lives on the server. It is never logged, never put in a
  file or chat, and nobody can read it back out — not even me.
- **No code is unbreakable.** A 4-digit code has only 10,000
  combinations, so short codes are refused. Use at least **8
  characters with letters and numbers**, and write it down
  somewhere private.
- **Lockout:** 3 wrong passcodes locks Connie for **15 minutes**.
  5 wrong sign-ins locks 5 minutes. 5 wrong voice checks locks
  5 minutes. A passed passcode check lasts 1 hour; a voice check
  lasts 5 minutes.
- **HTTPS-only when hosted:** set `HTTPS_ONLY=1` on the host and
  Connie only answers over HTTPS. Plain HTTP is refused (the
  health check at `/api/health` stays open so the host can check
  she is up).
- **No cookies at all** — sign-in uses a token in the request
  header. **Owner-only changes:** every write needs a signed-in
  owner session; visitors and anyone not signed in cannot change
  anything. **No secrets in the code, the zip or the logs** — AI
  keys only ever come from the server's own settings.
- **Honest limit:** no system is unhackable, and no code is
  unbreakable — this makes breaking in very hard, not impossible.
  The full list is in Settings → "Security — the security blanket".

## Download my stuff
Settings → "Backup & audit — Download my stuff": after the
two-step check (voice, then passcode, when set), George can
download his own records — everything, or learned notes only,
or invoices only — as a file to his phone or computer. Only his
own records ever come down; there is no other person's data in
Connie at all. Nothing downloads on its own, and nothing is
downloaded from the open internet.

## What Connie knows — and the law, in plain words
The **Learning** screen has two more panels:
- **"What Connie knows":** top brains — only 3 (Claude Fable 5.2,
  the #1 default, GPT-6.2 Astra, and Claude Opus 5.5 — top level only,
  no key set yet,
  so live AI is not connected); ask-first, George only; learn one
  thing at a time with your yes; multitasking on demand; voice
  recognition as a safety check only, not a secure ID.
- **"Law &amp; safety — what I know":** a short plain-words
  summary of the AI-law research done 16 November 2026 — no single
  federal AI law in the US as of Nov 2026, FTC rules (truthful ads,
  proof before claims, no fake reviews, no impersonation), Wyoming
  HB 102 (in force 1 July 2026, felonies for non-consensual
  synthetic sexual images), voice as the highest risk (a stored
  voiceprint is a biometric in Illinois, Texas, Washington,
  California and 20+ states; Illinois BIPA needs written notice and
  written consent before collecting), what never to do, ask-first,
  and what is needed before selling (Terms of Service, Privacy
  Policy, voice-consent policy, simple cancellation, a lawyer).
  **General information only — NOT legal advice. George should get
  a Wyoming lawyer to check things before selling anything.**
  The full research is saved at
  `workspace/research_notes/ai-laws-creating-selling-bot-20261116-1031/report.md`
  (76KB) and on the law page "AI Bot Laws — What George Needs to
  Know". The panel in the app is the summary, not the full report,
  and the full report was NOT copied into the app.

## Plug in any app — custom connectors
On the **Integrations** screen, "Add any connector / plug in a new
app" plugs in any app or bot George names — WhatsApp, QuickBooks,
his bank, another bot, anything. The form asks for the name, what
it should do, and the key/account to use — **name only**.
- **Keys stay on the server, never in chat.** Do NOT paste an
  actual secret key into the form — write only which account or key
  it is. The real key goes on the server only (see below), never in
  browser code, chat or Drive.
- A connector George adds is listed on the Integrations screen and
  Connie can talk about it ("what connectors do I have?"), but it
  is **plugged in, NOT connected** until (1) its key/account is set
  on the server and (2) George approves it on its card. Approving
  never connects it by itself — there is no live check for a custom
  connector. Nothing is auto-connected, auto-sent or auto-charged,
  ever. Ask-first, George-only permission still applies.

## Research to upgrade me — $250, ask first
A button on the Assistant screen: **"Research to upgrade me —
$250"**. Tapping it asks George first and shows the cost up front:
an **additional $250**, for Connie to do research so she can learn
and get smarter.
- Connie only researches **what George agreed to** — one topic he
  types in. She does **not** research everything in the world at
  once, and she does **not** learn on her own without permission.
- **No payment is live — nothing is charged here.** There is no
  Stripe and no checkout in this personal copy, so the $250 is a
  price George set, not a live charge. When payment is set up,
  George approves the $250 first, before any research starts.
- If no AI key is connected on the server, research cannot run at
  all, and Connie says so plainly — nothing is researched, nothing
  is charged.

## Safety & legal — in plain words (also in the app, Settings)
**Safe already:** George's records only; Connie asks first every
time; voice recognition is a safety check only; no audio stored;
no phone/screen access, no impersonation, no accessing other
people's phones; no live payments, no Stripe, no AI key.
**NOT done yet:** no hosting security review, no public web
address, no terms of service / privacy policy, no legal review.
Hosting is prepared (see `HOSTING.md`) but not deployed.
**This personal copy is NOT for sale at all.** If George ever
wants to sell a version of it, that version needs hosting + a
security review + Stripe + terms of service and a privacy policy
first, and **George should get a lawyer to check the terms before
selling.**

## How to run it locally
```sh
cd georges-assistant-connie
python3 server.py
```
Then open http://127.0.0.1:8765 in a browser. Create an account
(username 3–60 letters/numbers/underscores, password 12+ characters).
**Save the recovery code it shows you — it is shown only once.**
Records are stored in `georges_assistant.sqlite3` next to `server.py`.
Stop the server with Ctrl+C.

To run the tests:
```sh
python3 -m unittest discover -s tests -v
```

## Put Connie on your phone — plain steps
Connie is already a phone app — a home-screen app, **not** a Play Store
app. There is no app-store download, and no Play Store listing exists.

**Honest note first:** the home-screen icon alone does not run Connie.
Her server still has to be running somewhere — on your computer (steps
below), or on a hosted server. If the server is off, the app opens but
your records will not load.

1. On your **computer**, start the server so your phone can reach it:
   ```sh
   cd georges-assistant-connie
   HOST=0.0.0.0 PORT=8765 python3 server.py
   ```
   Leave that window open while you use it. (On Windows use
   `set HOST=0.0.0.0` first, then `python server.py`.)
2. Find your computer's address on your Wi-Fi: Windows — press
   Windows key + R, type `cmd`, type `ipconfig`, look for "IPv4
   Address" (looks like `192.168.1.23`). Mac — System Settings →
   Wi-Fi → click your network → the IP address is shown there.
3. On your **phone**, on the same Wi-Fi, open the browser and go to
   `http://<that number>:8765` — for example `http://192.168.1.23:8765`.
   Sign in with the same username and password you use on the computer.
4. Add her to your home screen:
   - **Android / Chrome:** in the app, go to **Settings → "Put Connie
     on my phone"** and tap **"Add Connie to my home screen"**. Or use
     the browser menu → "Add to Home screen".
   - **iPhone / Safari:** tap **Share**, then **"Add to Home Screen"**.
     (iPhone does not show the in-app install button — that is normal.)
   She will open full-screen, like an app, with her icon on your home
   screen.
5. When you are done, stop the server on the computer (Ctrl+C).
   **Home Wi-Fi only.** Do not open that port to the internet — the app
   is not ready for that (see HOSTING.md: it needs a host, a web
   address, HTTPS and a security review first).

Full phone details are in `PHONE.md` (including the hosted demo route,
which needs no computer but is sample data only).

## Settings (environment variables — never put these in a file you share)
Copy `.env.example` to `.env` on your own computer if you use one,
or set the variables when you start the server. Never put a key in
browser code, in chat, or in Drive.
- `HOST` (default `127.0.0.1`), `PORT` (default `8765`)
- `GEORGES_ASSISTANT_DB` — where the database file lives
- `ALLOW_SIGNUP` — `1` (open) or `0` (closed)
- `ANTHROPIC_API_KEY` + `ANTHROPIC_MODEL`, or `OPENAI_API_KEY` + `OPENAI_MODEL`,
  or `ANTHROPIC_API_KEY` + `OPUS_MODEL` (Opus shares the Anthropic key)
  — set one key to turn AI chat on. With no key, chat answers
  "AI is not connected yet" (HTTP 503). The key stays on the server.
  The models are already installed: `ANTHROPIC_MODEL` defaults to
  **claude-fable-5-2** (Claude Fable 5.2, #1, $8 per million input /
  $40 per million output, released 9 Nov 2026),
  `OPENAI_MODEL` defaults to **gpt-6.2-astra** (GPT-6.2 Astra, $8/$40,
  released 17 Nov 2026 — this updates the old GPT-6 Astra, $10/$50,
  in place), and `OPUS_MODEL` defaults to **claude-opus-5-5** (Claude
  Opus 5.5, $4/$20, same Anthropic key as Fable — no new key needed)
  — only 3 brains, top level only, no lower tiers are offered. A key
  alone counts as connected; you only set the model variable to
  override the default. `/api/status` reports them as `top_models`
  with `default_provider: "anthropic"` (Claude Fable 5.2 stays the
  default unless George picks another brain in the picker).
  Updated 2026-11-18 per George ("top three only, just put them on"):
  Fable was re-added as #1 after being removed 2026-11-16; rank #2
  Claude Mythos 5.2 was skipped — restricted to vetted organisations
  only. Removed 2026-11-18: Meta Muse Wonder, Google Gemini 4 Carbon
  and Grok 4.7. No Meta, Google or xAI key is used any more.
- `AI_HOURLY_LIMIT` (default **60** requests per user per hour for Connie — double the customer bot's 30; no 5-hour session limit for George)

## What is NOT live — needs George's own accounts, later
- **AI chat / research:** off until a server-side key is set (above).
- **Phone / receptionist:** not connected. Calls are logged by hand
  on the Front Desk tab. No call is answered, transferred or placed.
- **Payments / Stripe:** not connected. Nothing is for sale, there
  is no storefront and no checkout. The $250 research upgrade is
  not charged.
- **Bank feeds:** not connected. Money figures are George's own
  entered estimates, not bank balances.
- **Tax filing:** not connected. The 25% tax reserve is a bookkeeping
  estimate, not a tax determination and no money is moved.
- **Trading:** paper only. No broker is connected, no real money moves.
- **Calendar, email, Stripe:** real connectors added in v1.2 — live once their keys are set on the server (see "NEW in v1.2"). SMS and suppliers: not connected.
- **Crosswalk:** signup started Nov 6, 2026 was never finished, no
  key saved, no live connection, no connector to install.
- **Meta / Google / Grok:** removed 2026-11-18 — Connie now has
  only the top 3 usable brains (Fable, GPT-6.2 Astra, Opus). No Meta,
  Google or xAI key is used.
- **Remy:** no key exists and Remy is not live inside Connie.
  Remy lives in the Muse app, for George only.
- **Hosting:** this build is **hosting-ready** (2026-11-16, George
  approved): it binds the host's `PORT` on `0.0.0.0`, reads its
  database from `GEORGES_ASSISTANT_DB` (which must point at a
  persistent disk/volume, or her memory is wiped on restart), and
  serves plain HTTP behind the host's HTTPS. It is **NOT live on
  the internet yet** — no account, no deploy, nothing paid. See
  `HOSTING.md` for the plan: Railway is simplest, about $5 a month;
  Render about $7.25 a month; Fly.io about $4.50–$8 a month. George
  also asked for **1 TB of storage** — her real data is tiny
  (kilobytes), so 1 TB is far more than she will ever use, but the
  options are in `HOSTING.md`: Render about $257 a month (daily
  snapshots included), Railway Pro about $170–$180 a month,
  Fly.io about $152–$158 a month, Hetzner cloud about $70 a month
  (cheapest live disk). See `PHONE.md` for the two phone routes
  (same Wi-Fi, or the hosted phone demo).

## Copyright

<small>© 2026 George Wederski. All rights reserved. No part of this book/app may be copied, reproduced, or shared without written permission from George Wederski.</small>

## Not for sale
This personal copy is complete as a working local app and all
tests pass, but it is **not for sale and not ready to sell**: it has
not had a security review, it has no hosting, no payment provider,
no AI key, and no phone provider. Do not put real money through it
until those are in place and George has approved each one.
