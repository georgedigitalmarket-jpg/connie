# George's Assistant — Connie (personal copy)
Owner: George Wederski. Assistant name: Connie, in a girl's voice.

## All businesses in her books — 2026-11-25 (George: "run all my businesses so I don't have to", "put it in her")
- **Change:** Connie now keeps books for ALL of George's businesses, not just five. Added to her business list: Next Gen Production & Studios, G.W. Clothing Co, and George's Ad Agency — Gillette. Her full list is now: George's Little Handy Books, ALI — All-in-One Superbot, People's Bot, GDP — George's Digital Products, Next Gen Production & Studios, G.W. Clothing Co, George's Ad Agency — Gillette, Personal. Each keeps its own money in/out, profit/loss, and its own tax reserve, and each shows in the Money screen and in the pickers when she logs money, bills, or invoices.
- **What this does:** she tracks and watches every business — morning briefing across all of them, Business Watch flags overdue invoices, low stock, late tasks, spending ahead, and Stripe failed payments or disputes per business.
- **What it does NOT do yet:** she still cannot run them on her own around the clock — that needs hosting (so she is on 24/7, not only when the phone app is open), the live brain key (step 1, on hold by George), and a phone provider for answering calls. She also still asks first before paying, sending, buying, selling, or publishing anything.
- **Files changed:** `connie_plus.py` (DEFAULT_ACCOUNTS), `web/plus.js` (ACCOUNTS). `node --check` clean; server tests **38/38 pass**.
- **Not deployed:** this is the local copy only. The Drive zip still holds the old five-business build until it is re-zipped and uploaded.

## Auto-learn ON — 2026-11-25 (George: "turn on auto auto", yes to all)
- **Change:** Connie now learns on her own, without asking first. "learn this: ..." / "learn these: ..." saves right away, and things she notices worth remembering in what George says are saved right away too. Everything saved still shows on the Learning screen (searchable, no cap) with "Forget this" / "Forget everything".
- **What did NOT change:** the law refusal — unlawful notes are still refused, client-side and server-side (HTTP 400), and cannot be switched off. Learning is still local notes only: it does NOT retrain the model, does NOT change the model, does NOT go to the internet.
- **Off-switch:** Learning screen has "Turn auto-learn OFF — ask me first again" (and back on). Stored per browser in localStorage (`connie_auto_learn`); off restores the old ask-first flow exactly.
- **Files changed:** `web/app.js` (mLearn handler, `AUTO_LEARN` + `setAutoLearn`, Learning panel copy), `web/plus.js` (memory-suggestion flow auto-saves), `tests/test_server.py` (assertion updated to the new wording). `node --check` clean on both files; server tests **38/38 pass**.
- **Not deployed:** this is the local copy only. The Drive zip still holds the ask-first build until it is re-zipped and uploaded.

**Final file (this copy): `Georges_Assistant_Connie_2026-11-17.zip`
(118,189 bytes, 20 files, md5 c86037a0d04c86cc39e5b23a08ca4251),
re-zipped in place 2026-11-16 in
`~/workspace/user/files/georges-assistant-connie/`. Includes the
top brains (Fable 5.2 / GPT-6 Astra), Learn (one thing at a time),
plug-in-any-connector, and the law & safety knowledge panels, plus
Connie's girl voice, Research to Upgrade ($250, ask first), the
fine-print copyright (11px, right-aligned corner footer), and now
hosting-ready (Procfile, runtime.txt, render.yaml, HOSTING.md),
voice + passcode two-step check, the security blanket (HTTPS-only,
owner-only, no unauthenticated writes, rate limits), and
"Download my stuff" export. The copy of this status file inside
the zip lists the previous re-zip's figures, because a file cannot
list its own container's hash — the figures in this line, measured
from the rebuilt zip on disk, are the correct ones.**
Uploaded to Google Drive Lock — see the 2026-11-16 save note at
the end of this file. No Stripe, no AI key, no payment live.

<small>© 2026 George Wederski. All rights reserved. No part of this book/app may be copied, reproduced, or shared without written permission from George Wederski.</small>


## v1.2 Connie Plus — 2026-11-21 (George: "Connie upgrades", then "keep doing upgrades")
- **Built:** wake word "Hey Connie", morning briefing, real-time reminders (parse / due / snooze / repeat), Business Watch, separate business books per account (5 default accounts), bills with ask-first approve / not yet / mark paid, receipt reading (AI vision), make products & marketing drafts, All in One brain (parallel brains + Fable merge), memory upgrades (unlimited learned notes, topics, pin, smart recall, search, ask-first memory suggestions), offline mode (local copy + outbox), real connectors (Stripe read-only, Google Calendar read/add-after-yes, Google Drive file search + backups, email read / send-after-yes), nightly Drive backup + 14 local copies, `connect_google.py` one-time Google setup.
- **New files:** `connie_plus.py`, `connect_google.py`, `web/plus.js`, `web/csp-safe.js`, `tests/test_plus.py`. Changed: `server.py` (v1.2, Plus routes, bills kind, unlimited learned notes), `web/app.js`, `web/app.html`, `web/app.css`, `web/sw.js`, README, `.env.example`.
- **Bugs fixed:** the CSP blocked every inline handler (Add forms, Edit/Delete, many buttons did nothing; forms reloaded the page). Fixed by `web/csp-safe.js`, with the strict CSP kept. Research reply role "bot" broke the next live chat; leading assistant messages were sent to Claude. Both fixed.
- **Declined on purpose (George asked 2026-11-21):**
  - Connie paying bills or buying stocks on her own, including "only once if I'm not available". Every money move waits for his yes.
  - Ad money "by herself, 24/7". There is no real mechanism for that; ad income needs a site with visitors and his own ad account.
  - Told George plainly in chat.
- **Tests:** 38/38 pass (25 old + 13 new). Live browser smoke test on a phone-size screen: Today, reminder, briefing, memory suggestion → yes → "I learned", all tabs render, no JS errors (only the expected 503 with no AI key).
- **Still NOT live:** no AI key, no Stripe key, no Google sign-in, no email password, no bank, no hosting. Each connector is real code, but it has **not been tested against the live service** (no keys exist). A first real reply with George's keys is the proof.

## Top 3 usable brains ONLY — 2026-11-18 (George: "top three only, just put them on", no review)
- **Change:** Connie now has ONLY 3 brains, per the Nov 18 2026 ranking at https://theairankings.com/best-ai-models/:
  1. **Claude Fable 5.2** (`claude-fable-5-2`) — #1, score 65, $8/$40 per million tokens, released 9 Nov 2026. Top/default brain.
  2. **GPT-6.2 Astra** (`gpt-6.2-astra`) — #3 in the list, score 62, $8/$40, released 17 Nov 2026. Updates the old GPT-6 Astra (`gpt-6-astra`, $10/$50) in place.
  3. **Claude Opus 5.5** (`claude-opus-5-5`) — #4 in the list, score 59, $4/$20. Second Anthropic brain, same `ANTHROPIC_API_KEY` as Fable — no new key needed.
- **Rank #2 skipped:** Claude Mythos 5.2 is restricted to vetted organisations only — NOT added, and not offered.
- **This REVERSES the 2026-11-16 correction** that removed Fable entirely: George's latest instruction on 2026-11-18 was explicit — top three only, put them on, no review — so Fable returns as #1/default and Opus stays as the second Anthropic entry.
- **Removed 2026-11-18:** Meta Muse Wonder, Google Gemini 4 Carbon, Grok 4.7 — removed from `server.py` (`TOP_AI_MODELS`, `ai_model()`, `ai_providers()`, `call_ai()`), the picker and connector catalog in `web/app.js`, README, HOSTING.md and `.env.example`. No user-facing Wonder/Carbon/Grok text remains in `web/app.js`; the only mentions left are these dated removal notes. Older sections of this STATUS file still mention the removed brains — those are dated history, not current state.
- **Nothing else changed:** voice+passcode security, Fast Learn, 60 AI requests/hour, no 5-hour limit, ask-first, lawful-only limits all stay. No API key is set — all 3 brains still show "not connected" with no key. No live AI, no hosting, no payments.
- **Tests:** server tests 25/25 pass (top-brain assertions updated; mocked `call_ai` test now covers OpenAI/GPT-6.2 Astra). Live smoke check with no key: `/api/health` and `/api/status` 200, `top_models` = the 3 brains above, `providers` [], `default_provider` "anthropic", AI chat 503 ("AI is not connected yet") for both the default and Opus.
- **Re-zipped 2026-11-18** as `Georges_Assistant_Connie_2026-11-18.zip` (see figures at the top of this file). The 2026-11-17 zip was NOT overwritten or deleted. NOT uploaded to Google Drive.

This is George's own personal assistant — **NOT for sale**. It is a
personal copy of People's Bot v1.1 Upgraded (2026-11-17 zip,
727,617 bytes, md5 4a0107ea660f39b435010860722bfceb), copied from
`~/workspace/user/files/peoples-bot-v1-1-mobile/` on 2026-11-16.
The source folder and its zip were not touched or changed.
The source's `previous_versions/` folders were NOT copied — this
copy branches from the latest active build only, so no old
customer-facing People's Bot copy rides along.

## What changed 2026-11-16 — top brains, Learn, plug in any app, law knowledge
- **Top brains verified and reported:** `server.py` already had
  `DEFAULT_ANTHROPIC_MODEL = "claude-fable-5-2"`,
  `DEFAULT_OPENAI_MODEL = "gpt-6-astra"`, the `ai_model()` helper
  and key-only `ai_providers()` — all verified correct, no change
  needed there. Fixed the gap: `/api/status` now returns
  `top_models: {"anthropic": "claude-fable-5-2", "openai": "gpt-6-astra"}`
  and `default_provider: "anthropic"` (same two fields added to
  `/api/health`, plus a `learning` line). The Assistant picker
  already labelled them "Claude Fable 5.2 (Anthropic) — top level"
  and "GPT-6 Astra (OpenAI) — top level" with anthropic as the
  default. **No AI key is set, no live AI works, nothing is charged.**
- **Learn — one thing at a time, ask first:** new **Learning** tab
  (11 screens now). George says "learn this: ..." or "remember
  that ..." in the Assistant; Connie asks first, George says yes,
  she saves it as a `learned` record on this server only and says
  **"I learned: ..."** back, out loud and in chat. Say no and she
  saves nothing. Learned notes show on the Learning screen and in
  the Assistant, are sent with the question to the live AI (when a
  key is set) and are added server-side to the AI system prompt, so
  future answers use them. Learning is local notes only — it does
  NOT retrain the model, does NOT change the model, does NOT go to
  the internet. Forget one note or all of them from the Learning
  screen. George's words, kept in the panel: "I learn one thing at
  a time, only when you say yes — I do not learn everything in the
  world at once." Over time, one thing at a time, that can cover
  many things — never all at once, never without his yes.
- **Plug in any app — custom connectors:** the Integrations screen
  now has "Add any connector / plug in a new app" (name, what it
  does, key/account to use — name only). The form says plainly that
  keys stay on the server, never in chat, and not to paste a secret
  key into it. A custom connector is saved as a `connectors` record
  (`approved: false`), listed on the screen and by the Assistant
  ("what connectors do I have?"), and always says **"Plugged in —
  NOT connected"** until its key/account is set on the server and
  George approves it on its card — approving alone never connects
  it, because there is no live check for a custom connector.
  Nothing is auto-connected, auto-sent or auto-charged. Ask-first,
  George-only permission still applies.
- **Law & safety knowledge, in plain words:** the Learning screen
  has "What Connie knows" (top brains, ask-first, learn one thing
  at a time, multitasking on demand, voice-recognition limits) and
  "Law & safety — what I know" — a short summary of the AI-law
  research of 16 Nov 2026 (`workspace/research_notes/ai-laws-creating-selling-bot-20261116-1031/report.md`,
  76KB, NOT copied into the app): no single federal AI law as of
  Nov 2026, FTC rules, Wyoming HB 102, voice as the highest risk
  (BIPA etc.), what never to do, ask-first, and what is needed
  before selling (Terms, Privacy Policy, voice-consent policy,
  simple cancellation, a Wyoming lawyer). **General information
  only — NOT legal advice**, said plainly in the panel and in
  Settings. Connie refuses to learn or do anything against the law
  and says why — enforced in the Assistant and in the server
  (`/api/records` refuses an unlawful `learned` note, HTTP 400).
- **Fast Learn, faster, open knowledge, monthly upgrade — added 2026-11-16 (George's words: "learn everything, fast" / "it upgrades every month because it learns more stuff"):**
  - **Fast Learn:** "learn these: a; b; c" learns several things at once after one yes from George; each item is still saved one at a time, only after his yes, each gets its own "I learned: ..." back, and an unlawful item in a list is refused with its reason while the lawful ones are still saved. Ask-first per batch, never anything against the law.
  - **Faster than the customer bot:** `AI_HOURLY_LIMIT` is now **60 per user per hour** (double the customer bot's 30), and there is **no 5-hour session limit** for George — `/api/health` reports `ai_hourly_limit: 60` and `session_limit: "none — no 5-hour session limit for George"`.
  - **Open knowledge:** `learned_notes_text()` has no cap any more — it returns every learned note. The Learning screen shows all of them with a search box ("Search what I learned").
  - **Monthly upgrade — free for George:** Learning tab has "Show my monthly upgrade" (month picker + `GET /api/monthly-upgrade`), building e.g. "November upgrade: I learned 12 new things" labelled "Connie — November 2026 upgrade". The panel says plainly **"Your upgrades are free."** — Connie is George's personal bot, he pays nothing for her upgrades; no price or payment was added anywhere. The upgrade is a summary only: it does NOT retrain or change the model, does NOT change code, does NOT go to the internet. `POST /api/monthly-upgrade` with `approved: true` saves one `upgrades` record; with `approved: false` it saves nothing and changes nothing.
  - **Verification — done 2026-11-16:** server tests **19/19 pass**
  (`python3 -m unittest discover -s tests -v`), including new
  tests for top models, learned-note save/read/forget and unlawful
  refusal, and custom-connector records plus app strings.
  `node --check web/app.js` passed. Live smoke test on
  127.0.0.1:8799 with a temporary database (deleted after):
  `/api/health` 200 (`ai_enabled: false`, top models and default
  provider present), `/api/status` 200 (top models, default
  provider, `providers: []`), lawful learned note saved 201 and
  listed back, unlawful learned note refused 400 with the reason,
  custom connector saved, `/api/ai/chat` 503 (no key — correct),
  `/app.html` 200. No API key was set at any point. Server stopped,
  test database deleted, no database file left in this folder.

## What changed 2026-11-16 — hosting-ready, voice + passcode, security blanket, download, 1 TB plan
- **Hosting-ready (George approved, "so her voice works on any phone, anywhere, anytime"):** `server.py` binds `0.0.0.0` when `PORT` is set (host mode) and `127.0.0.1` at home, reads the database from `GEORGES_ASSISTANT_DB` (must point at a persistent disk/volume on the host, or her memory is wiped on restart), trusts the host proxy's `X-Forwarded-Proto` header, and `/api/health` already exists and is verified. Added `Procfile` (`web: python3 server.py`), `runtime.txt` (`python-3.12`), `render.yaml` (paid Starter only — the free Render tier has ephemeral disk and would wipe her memory). **HOSTING.md** is written in plain English: what hosting means, the steps George must do himself (make the host account with his card, deploy this folder only, set the AI key in the server settings, enrol his voice once), the costs, and the honest limits (voiceprint is not bank-grade, a recording could fool it; voice alone never authorises payments or taxes). Options checked 2026-11-16: **Railway — simplest, about $5 a month** (one-time $5 trial credit, 30 days, no card to try; Hobby $5 a month includes $5 of use; volume about $0.15/GB a month); **Render — about $7.25 a month** (smallest paid $7 a month + disk $0.25/GB a month; free $0 tier NOT to be used — sleeps after 15 minutes idle, no persistent disk, database wiped on restart); **Fly.io — about $4.50–$8 a month realistic** (no free tier for new accounts, only a trial; smallest machine about $1.94 a month, volume about $0.15/GB a month; harder — needs `flyctl` and a `Dockerfile`, not yet in this folder). AI brains cost extra, pay-as-you-go by the provider, not the host (Claude Fable 5.2 $8/$40 per million tokens, GPT-6 Astra $10/$50; normal chat a few cents or less). **Nothing has been bought, no account made, no deploy done — Connie is NOT live on the internet.**
- **Voice + passcode — two-step check (George: "only his voice, plus she must ask him for a passcode before she knows it's him, nobody else gets in"):** voice match first, then passcode, both required, in that order. Jobs (`/api/jobs`, `/api/jobs/batch`), AI chat (it reads his learned notes), Research to Upgrade and export/download are all gated by the two-step check. If neither voice nor passcode is set, jobs work as before (sign-in only).
- **Passcode storage — hash only, never plain text:** salted PBKDF2 hash (310,000 iterations, same as account passwords), never logged, never in chat, never in README or any file, never sent to the assistant. **No passcode was invented or assigned to George** — he sets it himself in Settings ("Set my passcode" flow, needs his account password to prove it is him; also to remove it). The 4-digit code George mentioned in voice was **not recorded** anywhere.
- **Honest limit, in the app:** no code is unbreakable; a 4-digit code has only 10,000 combinations. Short codes are refused (400) — minimum **8 characters, letters + numbers**. George chooses a long passcode himself and writes it down privately; nobody can look it up. **Lockout: 3 wrong passcode tries locks Connie for 15 minutes** (429 — even the right code is refused while locked). Sign-in: 5 wrong tries locks 5 minutes. Voice check: 5 wrong tries locks 5 minutes. A passed voice check lasts 5 minutes; a passed passcode check lasts 1 hour.
- **Security blanket (George: "nobody can hack it or change it"):** **HTTPS-only when hosted** (`HTTPS_ONLY=1` — plain HTTP refused 426 for data requests; `/api/health` and `/api/status` stay open so the host health check works; HTTPS via `X-Forwarded-Proto: https` allowed; no loopback exception); **no cookies at all** — sign-in uses a Bearer token header; security headers on every response (X-Content-Type-Options nosniff, X-Frame-Options DENY, Referrer-Policy no-referrer, CSP on app pages, HSTS `max-age=31536000` when HTTPS); **owner-only changes** — only George, signed in, can change settings, learned notes, connectors or the passcode; **no unauthenticated writes** — every write needs a signed-in owner session (401 without a token, tested); **no secrets in code, zip or logs** — API keys only via server env/settings. A plain **"Security — the security blanket" panel in Settings** lists what is protected and the honest limit: **no system is unhackable, no code is unbreakable — this makes breaking in very hard, not impossible.**
- **Download my stuff (George: "I want her to be able to download stuff too"):** Settings → "Backup & audit — Download my stuff": after sign-in + voice + passcode, George downloads his own records as a JSON file to his phone/computer — Everything, Learned notes only, or Invoices only. Only George can download, only his own records, nothing downloads on its own, and no other person's data exists in Connie anyway. Server `/api/export` is gated by the two-step check. No downloading from the open internet without George asking for a specific thing.
- **1 TB of storage (George: "I want her to have the best"):** honest note in HOSTING.md — her real data (learned notes, invoices, records) is tiny, kilobytes to megabytes, so 1 TB is far more than she will ever use. Options with at least 1 TB of live disk: **Render about $257 a month** (disk $0.25/GB + $7 service; daily snapshots, 7 days, included — best tier with backups built in); **Railway Pro about $170–$180 a month** (volume $0.15/GB + Pro $20; Hobby volumes cap at 5 GB, so Pro is needed; no automatic backups stated); **Fly.io about $152–$158 a month** (volume $0.15/GB + machine; snapshots charged extra, about $79 a month for a full 1 TB snapshot); **Hetzner cloud about $70 a month** (volume €0.0572/GB + small server — cheapest live disk; no automatic backups). Cheap storage that is **NOT** a live disk: Hetzner Storage Box 1 TB €3.20 a month and object storage about €6.49 a month — good for **backup copies only**, Connie's live database cannot run on them. Recommendation in HOSTING.md: start with a 1 GB disk (about 25 cents a month) — it already holds her whole life a thousand times over. **Nothing bought.**
- **Verification — done 2026-11-16:** server tests **25/25 pass** (was 19/19; +6 new: hosting bind, passcode set/check/hash-only, lockout, unauthenticated writes, HTTPS-only, export gating). `node --check web/app.js` passed. Live smoke test on 127.0.0.1:8811 with a temporary database (deleted after): health 200 with `security` in it, register 200, voice enrol 200, 4-digit passcode refused 400, long passcode set 200, voice check recognised, job with voice only refused 403, wrong passcode 401, job with voice + passcode 201, export without tokens 403, export with both 200, passcode status 200, 3 wrong passcodes → lockout 429 (even the right code refused while locked). HTTPS-only live check on 8812: health 200, plain-HTTP `/app.html` 426, with `X-Forwarded-Proto: https` 200. No API key set at any point. Servers stopped, test databases deleted, no database file left in this folder.

## What changed from the source (rebrand only, plus one new button)
- Name everywhere: **George's Assistant**, assistant name **Connie**,
  owner George Wederski only. App title, header, footer, manifest,
  service worker, server name, system prompt, export name, README.
- **Connie's default voice is a girl's voice, set right now:**
  on sign-in (`enterApp`) the app calls `ensureConnieGirlVoice()`,
  which picks the first female voice on George's own device if no
  voice is saved yet. `chosenSpeechVoice()` also falls back to the
  first female voice. Connie introduces herself as Connie in a
  girl's voice ("Hello, George. I'm Connie, your personal
  assistant, in a girl's voice.") and there is a "Hear Connie say
  hello" button. George can still ask her to change to a different
  girl voice later ("change your voice to a girl voice",
  "an Australian girl voice", "a Mexican voice").
- **Removed:** all selling and customer-plan wording — no pricing
  tiers, no free tier, no usage limits to buy, no storefront
  (`web/store.html` and `web/store.js` deleted; `/api/store/` now
  returns `store_available: false` with no products), no
  publish-for-sale (product status is now Draft / Ready, and the
  product-draft job counts Ready products). The Settings Plans &
  pricing panel is replaced by "Personal copy — no plans, no
  prices". The Safety & legal panel now says this copy is NOT for
  sale at all.
- **New — Research to upgrade me ($250, ask first):** a button on
  the Assistant screen. Tapping it asks George first, shows the
  additional $250 cost, and asks for one topic to research.
  Connie only researches what George agreed to — never everything
  in the world at once, never without permission. **No payment is
  live — nothing is charged:** no Stripe, no checkout. If no AI
  key is connected, research cannot run and Connie says so plainly.
  Asking in chat ("research to upgrade me") points George to the
  button.
- **Kept unchanged:** all 11 screens (Learning added 2026-11-16); multitasking on-demand only;
  voice recognition (only George's enrolled voice can start jobs);
  voice choice / change by asking; ask-first permission (Connie
  asks George first, George only — `/api/health` reports
  `assistant: "Connie"`, `personal_copy: true`,
  `permission_model: "ask-first, George only"`); Safety & Legal
  in plain words; provider picker (OpenAI / Claude, key on server
  only); Integrations / Crosswalk slots (none live).
- **Copyright fine print (2026-11-16, George's correction):** the notice is now FINE PRINT — 11px, right-aligned, tucked in the corner of the footer (`<small class="fineprint">`), not big and bold; the Assistant-screen notice is a small fine-print line instead of a panel. Exact words unchanged.
- **Copyright (added 2026-11-17):** the notice "© 2026 George Wederski. All rights reserved. No part of this book/app may be copied, reproduced, or shared without written permission from George Wederski." is in the app footer (`web/app.html`), the Assistant screen and the `web/app.js` header, `README.md`, this status file, `server.py`, `web/sw.js`, `HOSTING.md` and `PHONE.md`. No file says the app can be copied or shared freely. Registering the copyright is a separate step George does himself — see `COPYRIGHT-REGISTRATION-READY.md` (prepared, not submitted). It now also has a filled-in DRAFT for the eCO form, screen by screen (title, author George Wederski, 2026, computer program / literary work, claimant George Wederski, unpublished, upload the Connie zip, Single $45 / Standard $65), with George's address, phone, email, date of birth, payment card and signature left blank for him to fill in himself.
- Database file is now `georges_assistant.sqlite3`
  (`GEORGES_ASSISTANT_DB`).
- **Phone app — added 2026-11-16 (George: "make it an app on my phone, so I can use it"):** Connie was already phone-friendly PWA code and this was verified, not assumed — `web/manifest.webmanifest` (name "George's Assistant", `display: standalone`, `start_url: /app.html`, real 192×192 and 512×512 PNG icons, now with `maskable` entries too), `web/sw.js` (caches only the app shell, never `/api/`), `web/app.html` (viewport, theme-color, manifest link, apple-touch-icon, iOS standalone metas), `web/app.js` registers the service worker, and `web/app.css` has the phone layout (`@media max-width:700px`, single column, 44px+ tap targets, 16px inputs so the phone does not zoom). **New:** Settings now has a "Put Connie on my phone" panel with an **"Add Connie to my home screen"** button — it uses the browser's install prompt on Android/Chrome (`beforeinstallprompt`), and on iPhone (which never offers that prompt) it says so and points to Share → Add to Home Screen. **Honest limit, stated in the app and in README:** the home-screen icon alone does not run Connie — her server still has to be running on George's computer (same Wi-Fi, `HOST=0.0.0.0 PORT=8765 python3 server.py`) or on a hosted server; if the server is off, the app opens but records will not load. **This is NOT a Play Store app** — no app-store download exists, and none was claimed. Plain steps are in README.md ("Put Connie on my phone") and `PHONE.md`. Verified live 2026-11-16 on port 8807 with `HOST=0.0.0.0` (bind confirmed): `/app.html`, `/app.js`, `/app.css`, `/manifest.webmanifest`, `/sw.js`, both icons all 200 with correct content types; manifest parsed (standalone, maskable icons); served `app.js` contains the install code; `/api/health` 200 (Connie, 60/hour, no 5-hour limit). Test server stopped, temp DB deleted.
- **Monthly-upgrade smoke test — fixed and proved live 2026-11-16:** the earlier `KeyError: 'label'` was a bug in the test script (it passed the sign-in token as the request body instead of the Authorization header), not in the server. Re-run clean on port 8805: health 200 (60/hour, no 5-hour limit), status 200 (top models Fable 5.2 / GPT-6 Astra, no key, nothing charged), register 200, Fast Learn 3 notes saved 201, unlawful learn refused 400, monthly-upgrade GET 200 — "Connie — November 2026 upgrade", "November upgrade: I learned 3 new things", free: true, items listed — refuse October saved nothing (0 upgrades records), approve November 200 saved one record, AI chat 503 with no key. Server stopped, temp DB deleted.

## Verification — done 2026-11-16 (updated: 19/19 tests, see the
2026-11-16 section above for the latest run)
- Server tests: **19/19 pass** (`python3 -m unittest discover -s
  tests -v`), including the new no-storefront / Connie test
  (no $15/$75/$150/$299 in app.js, no "People's Bot" in app.js,
  health reports Connie) plus new tests for top brains, learned
  notes (save/read/forget, unlawful refusal), custom connectors,
  Fast Learn + open knowledge (no cap), Connie's faster speed
  (60/hour, no 5-hour limit), and the free monthly upgrade
  (summary, approve saves one record, refuse saves nothing).
  `node --check web/app.js` passed.
- Live run on 127.0.0.1:8791 with a temp database (deleted after):
  `/api/health` 200 — `live_payments: false`,
  `assistant: "Connie"`, `personal_copy: true`,
  `permission_model: "ask-first, George only"`;
  `/app.html` 200, `/store.html` 404,
  `/api/store/george` returns `store_available: false`;
  served `app.js` contains "Hello, George. I'm Connie",
  "Hear Connie say hello", "Research to upgrade me",
  `ensureConnieGirlVoice`. Server stopped, test database deleted,
  no database file left in this folder.
- Source untouched: the source zip still measures 727,617 bytes,
  md5 4a0107ea660f39b435010860722bfceb.

## Still NOT live
No hosting, no security review, no AI key, no Stripe/checkout,
no phone provider. This copy is personal only — it is not for
sale, and it is not ready to sell a version of it either until
hosting + security review + Stripe + terms of service and a
privacy policy are in place and a lawyer has checked the terms.

## Saved to Drive Lock — 2026-11-16
Re-zipped after the hosting / passcode / security-blanket /
download / 1 TB work above: `Georges_Assistant_Connie_2026-11-17.zip`,
**118,189 bytes, 20 files, md5 c86037a0d04c86cc39e5b23a08ca4251**,
`unzip -t` clean. Uploaded to the Drive Lock folder
(`1Bpzdr3ZeQ7-I4JsYpS6OfaFwVaqU-1ho`) as Drive file
**`1oYV-dAkfud8LKxn_2_d_YUy0hfnpFyjc`** —
https://drive.google.com/file/d/1oYV-dAkfud8LKxn_2_d_YUy0hfnpFyjc/view
— verified after upload: Drive size 118189 and md5
c86037a0d04c86cc39e5b23a08ca4251 both match the local zip exactly.
No passcode, API key or .env is in the zip or on Drive. The zip's
own copy of this status file predates this save note by one edit
(see the note at the top of this file).

## Meta Muse Wonder — third top brain, added 2026-11-16 (George asked for Meta's top AI in Connie)
- **Verified 2026-11-16 (web search):** Meta's most capable model is Muse Wonder, announced Oct 12 2026, model ID `muse-wonder-1.0`, via the Meta Model API (base https://api.meta.ai/v1 — OpenAI-compatible chat completions), $4.00 per million input / $20 per million output tokens (cached input $0.20), ~1M-token context, still labelled Preview. Muse Wonder Full is NOT on the API (Muse Code subscriptions only) and was not added.
- **Wired in as a third provider (Connie only):** `server.py` — `DEFAULT_META_MODEL = "muse-wonder-1.0"`, `TOP_AI_MODELS` now has anthropic/openai/meta, `meta_api_key()` reads `META_API_KEY` or `META_MODEL_API_KEY`, `ai_providers()` reports "meta" only when a Meta key is set, `call_ai("meta", ...)` posts to `https://api.meta.ai/v1/chat/completions` with a Bearer key and OpenAI-style choices parsing. Picker in `web/app.js` shows "Meta Muse Wonder (Meta) — top level" alongside Claude and ChatGPT; default stays Claude Fable 5.2 unless George picks Meta. Integrations catalog has a Meta entry (needs his own Meta key). README and `.env.example` updated.
- **No Meta key is set — nothing invented, nothing charged.** Live AI still needs George's own Meta API key in the server settings. **The live Meta call has NOT been tested** (no key exists to test with): the endpoint is OpenAI-compatible per Meta's public docs, but a first live reply with a real key is the proof, not this code. With no key, `/api/status` reports providers `[]` and AI chat is 503, as before.
- Tests: server tests now 25/25 (updated top-brain assertions + Meta alias tests). Smoke test with no key: status 200, top_models includes meta, providers [], AI chat 503.

## Re-zipped after Meta Muse Wonder — 2026-11-16
`Georges_Assistant_Connie_2026-11-17.zip`, **120,443 bytes, 20 files, md5 747fe094585ab8df2784ea8cefc19724**, `unzip -t` clean. No passcode, API key, .env or .sqlite3 in the zip. NOT uploaded to Google Drive yet (the Drive copy, file 1oYV-dAkfud8LKxn_2_d_YUy0hfnpFyjc, is the previous 118,189-byte build). The zip's own copy of this status file predates this save note by one edit, as before.

## Google Gemini 4 Carbon — fourth brain, added 2026-11-16 (George approved, after the top-brains research)
- **Verified 2026-11-16 (research):** Google's top Gemini model, GA on the paid Gemini API Nov 10 2026, model ID `gemini-4-carbon`, $2.00 per million input / $10 per million output until Nov 30 2026, then $4/$20 from Dec 1 2026, 1,048,576-token context, no free tier. Ranked #2 in the research — behind Claude Fable 5.2 (#1) only.
- **Wired in as a fourth provider (Connie only):** `server.py` — `DEFAULT_GOOGLE_MODEL = "gemini-4-carbon"`, `TOP_AI_MODELS` now has anthropic/opus/openai/meta/google, `google_api_key()` reads `GOOGLE_API_KEY` or `GEMINI_API_KEY`, `ai_providers()` reports "google" only when a Google key is set, `call_ai("google", ...)` posts to the Gemini API `generateContent` endpoint (`https://generativelanguage.googleapis.com/v1beta/models/gemini-4-carbon:generateContent`, `x-goog-api-key` header, system as `systemInstruction`, chat roles user/model, `candidates[0].content.parts[].text` parsing — a different shape from the OpenAI-compatible calls used by OpenAI/Meta). Picker in `web/app.js` shows "Google Gemini 4 Carbon (Google) — top level" alongside the others; default stays Claude Fable 5.2. Integrations catalog has a Google entry (needs his own Google key). README and `.env.example` updated.
- **No Google key is set — nothing invented, nothing charged.** Live Google chat needs George's own Google API key in the server settings. **The live Google call has NOT been tested** (no key exists to test with): a first live reply with a real key is the proof, not this code. With no key, `/api/status` reports providers `[]` and AI chat is 503, as before. The request shape was verified by a mocked-transport unit test (correct URL, key header, and reply parsing).
- Tests: server tests 25/25 (top-brain assertions updated + Google alias and mocked `call_ai` tests). Smoke test with no key: health/status 200, top_models includes google, providers [], signed-in AI chat for google returns "AI is not connected yet".

## Claude Opus 5.5 — extra Anthropic choice, added 2026-11-16 (George approved, after the top-brains research)
- **Verified 2026-11-16 (research):** Claude Opus 5.5, model ID `claude-opus-5-5`, $4.00 per million input / $20 per million output, Anthropic's recommended daily driver, ranked #3 behind Fable 5.2 (#1) and Gemini 4 Carbon (#2). **It is NOT above Fable — it is an extra, cheaper Anthropic option alongside Fable.**
- **Wired in (Connie only):** `server.py` — `DEFAULT_OPUS_MODEL = "claude-opus-5-5"`, `TOP_AI_MODELS` has an "opus" entry, `ai_model("opus")` returns it (env `OPUS_MODEL` overrides), `ai_providers()` reports "opus" whenever the Anthropic key is set — **same `ANTHROPIC_API_KEY` as Fable, no new key** — and `call_ai("opus", ...)` uses the same Anthropic Messages endpoint as Fable with the Opus model. Picker in `web/app.js` shows "Claude Opus 5.5 (Anthropic)" second, after Fable. Integrations catalog has an Opus entry. README and `.env.example` updated.
- **Claude is the one on top — confirmed by George 2026-11-16 (Clyde = Claude).** Default/top brain stays Claude Fable 5.2 (`claude-fable-5-2`): the picker lists Fable first and selected by default, `/api/status` reports `default_provider: "anthropic"`, and README/STATUS say so. Gemini 4 Carbon and Claude Opus 5.5 are extra choices below it, not the top.
- Tests: server tests 25/25 (Opus assertions + shared-key provider test). Smoke test with no key: top_models includes opus, providers [], signed-in AI chat for opus returns "AI is not connected yet" (no Anthropic key set).

## CORRECTION 2026-11-16 — only ONE Claude: Opus 5.5 on top, Fable 5.2 REMOVED; Grok 4.7 added
- **George's correction, in order:** (1) only one Claude — keep Claude Opus 5.5 (`claude-opus-5-5`) on top as the default, and REMOVE Claude Fable 5.2 from Connie entirely. (2) After Gemini 4 Carbon, add Grok's best brain: Grok 4.7.
- **Fable removal — done:** `server.py` — `DEFAULT_ANTHROPIC_MODEL` is now `"claude-opus-5-5"`, the separate "opus" provider entry is gone, `TOP_AI_MODELS` is `{"anthropic": "claude-opus-5-5", "openai": "gpt-6-astra", "meta": "muse-wonder-1.0", "google": "gemini-4-carbon", "grok": "grok-4.7"}`. Picker in `web/app.js` lists `["anthropic", "openai", "meta", "google", "grok"]` with "Claude Opus 5.5 (Anthropic) — top level" first and selected by default; no "Fable" text remains in `web/app.js`, `server.py` (except the two removal-note comments), README, HOSTING.md or `.env.example`. Tests assert `assertNotIn("Fable", app_js)` and that "opus" is not a provider. **Note: older sections of this STATUS file still mention Fable — those are dated history of what was installed before this correction, not current state. Current state is this section.**
- **Grok 4.7 — wired in as a fifth provider (Connie only):** verified 2026-11-16 (research): xAI's best brain, model ID `grok-4.7`, via the xAI API (console.x.ai), $2.00 per million input / $6 per million output under a 200k prompt ($4/$12 at or above), 500k context. `server.py` — `DEFAULT_GROK_MODEL = "grok-4.7"`, `grok_api_key()` reads `XAI_API_KEY`, `ai_providers()` reports "grok" only when an xAI key is set, `call_ai("grok", ...)` posts to `https://api.x.ai/v1/chat/completions` with a Bearer key and OpenAI-style choices parsing. Picker shows "Grok 4.7 (xAI) — top level". Integrations catalog has a Grok entry (needs his own xAI key). README, HOSTING.md and `.env.example` updated.
- **Final brain list for Connie:** Claude Opus 5.5 (top/default, the only Claude), GPT-6 Astra, Meta Muse Wonder, Google Gemini 4 Carbon, Grok 4.7.
- **No keys are set — nothing invented, nothing charged.** Live Grok chat needs George's own xAI API key in the server settings. **The live Grok call has NOT been tested** (no key exists to test with): a first live reply with a real key is the proof, not this code. With no keys, `/api/status` reports providers `[]` and AI chat is 503, as before.
