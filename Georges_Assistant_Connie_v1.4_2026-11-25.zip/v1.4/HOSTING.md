# Hosting Connie — so she works on any phone, anywhere, anytime

**What this is:** Connie lives on George's computer right now. That is
why she only works at home, on the same Wi-Fi. **Hosting** means
putting her on a computer on the internet that stays on all the time,
so any phone, anywhere, can reach her — and her voice check works
there too. George approved this on 2026-11-16.

**Connie is NOT live on the internet yet.** Nothing in this folder
has been deployed, no account has been made, nothing has been paid.
This file is the plan. The live step needs George's own account and
his say-so at each step below.

## What hosting changes, in plain words
- **Before:** Connie only works when George's computer is on, at
  home, on the same Wi-Fi. Her voice enrolment and everything she
  learned live in a file on that computer.
- **After:** Connie runs day and night on a hosted computer. George
  opens her on any phone, signs in, and she knows his voice. He
  enrols his voice **once** (in Settings, with his say-so), and
  that enrolment is stored on the hosted server, so it works from
  any phone — not just the one he enrolled on.
- **What does NOT change:** Connie still asks first, every time.
  She still only works for George. Her upgrades are still free for
  him. She still does not retrain or change her own brain, and she
  still does not learn anything without his yes.

## The one thing that can go wrong — her memory
Connie's memory (everything she learned, and George's voice
enrolment) lives in one database file. On most hosts, the app's own
folder is **wiped every time the host restarts or updates her**.
If the database lives there, she forgets everything she learned
and George has to enrol his voice again.

So the database **must** live on the host's **persistent disk /
volume** — a part of the disk the host promises to keep. On all
three options below that is a setting, not code: set
`GEORGES_ASSISTANT_DB=/data/georges_assistant.sqlite3` (that
`/data` folder is the persistent disk). The code already reads
that setting. **Back it up** — download a copy of the database
file now and then, and keep it somewhere private, never on Drive.

## Three simple options (checked 2026-11-16 — check the price again before paying, prices change)

### 1. Railway — simplest for Connie. About $5 a month. (Recommended)
- **Cost:** a one-time $5 trial credit for 30 days, no card needed
  to try it. After that, the **Hobby plan is $5 a month**, and that
  $5 includes $5 of usage — a small app like Connie, running all
  the time, usually lands inside that $5. If she uses more, it is
  billed per second after that (about $10 per GB of memory a month,
  $20 per vCPU a month). A persistent volume for her memory costs
  about $0.15 per GB a month — a 1 GB volume is about 15 cents.
  **Realistic total: about $5 a month.**
- **Why it fits Connie:** Railway gives the app a `PORT` number
  and the server already listens on it; it gives her a web address
  with HTTPS automatically; and a volume keeps her database safe
  across restarts. Easiest of the three to set up.
- **Steps:** make a Railway account → new project → deploy this
  folder from GitHub (or the Railway CLI) → add a volume mounted
  at `/data` → set the settings below → set the health check to
  `/api/health` → open her web address and sign in.

### 2. Render — also simple. About $7 a month.
- **Cost:** the **free** service is $0, but **do NOT use it for
  Connie** — a free service sleeps after 15 minutes with no
  visitors, takes about a minute to wake up, and **cannot have a
  persistent disk, so her database is wiped on every restart**.
  The smallest paid service is **$7 a month** (512 MB, no sleep),
  plus a persistent disk at **$0.25 per GB a month** — a 1 GB disk
  is 25 cents. **Realistic total: about $7.25 a month.**
- **Why it fits:** a `render.yaml` file is already in this folder
  with the right settings; Render gives her a web address with
  HTTPS automatically; the health check is `/api/health`.
- **Steps:** make a Render account → new web service from this
  folder → pick the Starter ($7) plan → attach a 1 GB disk at
  `/data` → set the settings below → open her web address.

### 3. Fly.io — cheapest, hardest to set up. About $2–$8 a month.
- **Cost:** no free tier for new accounts any more — only a trial
  of 2 hours of computer time or 7 days, whichever ends first,
  then pay-as-you-go with a card on file. The smallest machine
  (256 MB) is about **$1.94 a month**, a persistent volume is
  about **$0.15 per GB a month**. A real always-on Connie with
  her memory kept safe usually lands around **$4.50–$8 a month**
  once computer, volume and internet traffic are added up.
- **Why it is third:** it works, and it is cheap, but it needs a
  command-line tool (`flyctl`) and a `Dockerfile` (not in this
  folder yet), so it is more fiddly than Railway or Render.
- **Steps:** make a Fly.io account → install `flyctl` → make an
  app and a volume → write a small `Dockerfile` → deploy → set
  the settings below.

## George wants 1 TB — the best (added 2026-11-16)

**Honest first:** Connie's actual data — learned notes, invoices,
records, all plain text — is **tiny: kilobytes to megabytes**.
She will never fill even 1 GB, let alone 1 TB. 1 TB is about a
million times more room than she will ever use. But George asked
for the best, so here is what 1 TB actually costs — and what is
smart about it.

| Where the 1 TB lives | What it costs a month | Backups included? |
|---|---|---|
| **Render** — 1 TB persistent disk | **about $250 a month** just for the disk ($0.25 per GB), plus the $7 service = **about $257 a month** | Yes — Render snapshots the disk once a day and keeps 7 days |
| **Railway** — 1 TB volume (needs the Pro plan; Hobby volumes cap at 5 GB) | **about $150 a month** for the volume ($0.15 per GB), plus Pro $20 a month, plus computer use = **about $170–$180 a month** | No automatic backups stated — download your own backup copy (Settings → "Download my stuff") |
| **Fly.io** — 1 TB volume | **about $150 a month** for the volume ($0.15 per GB), plus the machine about $2–$8 = **about $152–$158 a month** | Snapshots are charged extra: $0.08 per GB a month after the first 10 GB free — a full 1 TB snapshot would be about $79 a month more |
| **Hetzner cloud** — 1 TB block volume + a small server (cheapest live disk) | Volume about **€57 a month** ($0.0572 per GB), plus a small server about €5–€7 = **about €62 a month (about $70)** | No automatic backups — download your own backup copy |

**What is NOT a live disk — do not be fooled by the cheap price:**
- **Hetzner Storage Box, 1 TB for €3.20 a month** — that is a
  network drive for **backup copies only**. Connie's live
  database cannot run on it (it is reached over the network, and
  a live database file on a network drive is unreliable). It is
  a good, cheap place to keep a **backup copy** of her memory.
- **Object storage (Hetzner €6.49 a month for 1 TB, Backblaze B2
  about $6–$7 a month for 1 TB)** — same story: cheap storage
  for files and backup copies, not a live database disk.

**Recommendation, plain:** start with a **1 GB disk** (about
25 cents a month on Render, 15 cents on Railway/Fly.io) — that
already holds Connie's whole life a thousand times over. If
George still wants the full 1 TB, the best-value live option is
**Hetzner cloud at about $70 a month**, and the simplest
best-tier option with backups built in is **Render at about
$257 a month** (daily snapshots, 7 days). **Nothing has been
bought** — these are prices checked 2026-11-16; check them
again before paying, because prices change.

**Backups, whatever the size:** the best tier should include
backups. Render's disk snapshots (daily, 7 days) are the only
one of the three above that includes them. On Railway and
Fly.io, the backup is George's own job: Settings → "Download
my stuff" downloads his records as a file — do that now and
then, and keep the file somewhere private. A cheap Hetzner
Storage Box (€3.20 a month for 1 TB) is a good second copy.

**On top of hosting, the AI brains cost extra — pay-as-you-go,
billed by Anthropic / OpenAI, not by the host.** Connie's brains
are Claude Fable 5.2 ($8 per million input / $40 per million
output), GPT-6.2 Astra ($8 / $40) and Claude Opus 5.5 ($4 / $20). A normal chat costs
a few cents or less. George pays that on his own Anthropic or
OpenAI account, only when he uses it. With no key set, Connie
still works for records, learning and jobs — she just says "AI
is not connected yet" for live chat.

## Steps George must do (nobody else can do these for him)
1. **Pick a host** (Railway is the simplest — about $5 a month)
   and make an account in his own name, with his own card.
2. **Deploy this folder** to that host (steps above). Do not
   deploy the demo or People's Bot — this folder only.
3. **Set these on the host, in its dashboard** — never in code,
   chat or Drive:
   - `GEORGES_ASSISTANT_DB=/data/georges_assistant.sqlite3`
     (the persistent disk — this is the step that keeps her memory)
   - `ALLOW_SIGNUP=0` — after George's own account exists, so
     nobody else can sign up
   - `HTTPS_ONLY=1` — Connie then only answers over HTTPS (the
     host's proxy adds it). Plain HTTP is refused, except the
     health check at `/api/health` so the host can check she is up.
   - `ANTHROPIC_API_KEY` **or** `OPENAI_API_KEY` — one is enough
     for live AI chat. The brains are already installed
     (Claude Fable 5.2 by default; GPT-6.2 Astra and Claude Opus 5.5
     as the other two — only 3 brains, updated 2026-11-18).
4. **Check she is up:** open her new web address, add
   `/api/health` to the end of it — it should answer 200 and say
   Connie, with `ai_enabled: true` once the key is set.
5. **Sign in** with his username and password, and **save the
   recovery code** (shown only once).
6. **Enrol his voice once** — in the app, Settings → voice
   recognition, with his say-so. After that, any phone he signs
   in on will know his voice. Add her to the phone's home screen
   (Settings → "Put Connie on my phone").
7. **Back up her memory** now and then: download the database
   file from the host's disk and keep it private.

## Honest limits — read these before going live
- **Voice is a safety check, not a secure ID.** Connie works out
  16 numbers from the sound of George's voice and sends only
  those numbers to the server — **no audio recording is stored**.
  A recording of his voice could fool it, and a cold or background
  noise can make it fail. **Voice alone NEVER authorises** taxes,
  bank access, payments, publishing or sending — those still need
  a separate yes, every time.
- **Voice enrolment is a biometric.** In some states (Illinois,
  Texas, Washington, California and others) a stored voiceprint
  counts as a biometric and needs written notice and written
  consent before it is collected. This is general information
  only, not legal advice — George should get a Wyoming lawyer
  to check it before anyone else uses Connie.
- **No security review yet.** Sign-in, sessions, backups and data
  deletion were tested locally, but the app has not been reviewed
  for production use on the open internet. Do not put real money
  through it, and keep the database backed up and private.
- **The host's HTTPS is what keeps the connection safe.** The
  server itself serves plain HTTP behind the host's proxy — the
  host (Railway / Render / Fly.io) adds the HTTPS. Never expose
  `python3 server.py` directly to the internet without that.
- **AI costs are separate** (see above) and the brains only work
  once a key is set on the server. No key is set in this folder.
- **New brains:** Connie does **not** grab a new brain on her own.
  When a new top brain comes out, George is shown it, says yes,
  and it is added for her — within the law.

## Do not do
- Do not upload the database file to Drive or share it.
- Do not put API keys, passwords or recovery codes in code, chat,
  Drive, or a store page.
- Do not claim live AI, live phone, live payments, live bank feeds,
  live tax filing, or live trading until each provider is actually
  connected and tested — the app says "not connected" for all of
  them until then.
- Do not use Render's free service for Connie — it wipes her memory.

<small>© 2026 George Wederski. All rights reserved. No part of this book/app may be copied, reproduced, or shared without written permission from George Wederski.</small>
