"""Connie Plus (v1.2) tests — run: python3 -m unittest discover -s tests -v
No network, no keys: connectors are tested with mocks only."""
import datetime as dt
import json
import os
import sys
import tempfile
import threading
import unittest
from pathlib import Path
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
import server  # noqa: E402
import connie_plus as plus  # noqa: E402
from test_server import req  # noqa: E402


class PlusTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tmp = tempfile.TemporaryDirectory()
        cls.db = Path(cls.tmp.name) / "plus.sqlite3"
        cls._patches = [patch.object(server, "DB", cls.db),
                        patch.object(plus, "SECRETS_FILE", Path(cls.tmp.name) / "none.json"),
                        patch.dict(os.environ, {"CONNIE_BACKUP_DIR": str(Path(cls.tmp.name) / "bk")})]
        for p in cls._patches:
            p.start()
        for k in ("STRIPE_SECRET_KEY", "GOOGLE_CLIENT_ID", "EMAIL_ADDRESS", "GOOGLE_CALENDAR_ICS_URL", "ANTHROPIC_API_KEY", "OPENAI_API_KEY"):
            os.environ.pop(k, None)
        cls.srv = server.make_server("127.0.0.1", 0)
        cls.base = f"http://127.0.0.1:{cls.srv.server_address[1]}"
        threading.Thread(target=cls.srv.serve_forever, daemon=True).start()
        s, d = req(cls.base, "POST", "/api/register", {"username": "george_plus", "password": "correct-horse-battery-123"})
        assert s == 200, d
        cls.t = d["token"]

    @classmethod
    def tearDownClass(cls):
        cls.srv.shutdown()
        for p in reversed(cls._patches):
            p.stop()
        cls.tmp.cleanup()

    def add(self, kind, data):
        s, d = req(self.base, "POST", "/api/records", {"kind": kind, "data": data}, self.t)
        self.assertEqual(s, 201, d)
        return d["id"]

    # ---------- reminders ----------
    def test_reminder_parser(self):
        now = dt.datetime(2026, 11, 21, 15, 0, tzinfo=plus.tz())   # a Saturday
        r = plus.parse_reminder("remind me to call Smith tomorrow at 3pm", now)
        self.assertEqual(r["title"], "Call Smith")
        self.assertEqual(r["at"][:16], "2026-11-22T15:00")
        r = plus.parse_reminder("remind me in 20 minutes to check the oven", now)
        self.assertEqual(r["at"][:16], "2026-11-21T15:20")
        self.assertIn("oven", r["title"].lower())
        r = plus.parse_reminder("remind me to pay rent every monday at 9am", now)
        self.assertEqual(r["repeat"], "weekly")
        self.assertEqual(r["due"], "2026-11-23")
        r = plus.parse_reminder("remind me to order paint on friday", now)
        self.assertEqual(r["due"], "2026-11-27")
        r = plus.parse_reminder("remind me to water plants", now)
        self.assertTrue(r["guessed"])

    def test_reminders_due_done_snooze_repeat(self):
        past = (plus.now_local() - dt.timedelta(minutes=5)).isoformat(timespec="minutes")
        rid = self.add("reminders", {"title": "Feed the dog", "at": past, "done": False})
        s, d = req(self.base, "GET", "/api/reminders/due", token=self.t)
        self.assertIn(rid, [r["id"] for r in d["due"]])
        s, d = req(self.base, "POST", f"/api/reminders/{rid}/snooze", {"minutes": 10}, self.t)
        self.assertEqual(s, 200)
        s, d = req(self.base, "GET", "/api/reminders/due", token=self.t)
        self.assertNotIn(rid, [r["id"] for r in d["due"]])
        rep = self.add("reminders", {"title": "Daily check", "at": past, "repeat": "daily", "done": False})
        s, d = req(self.base, "POST", f"/api/reminders/{rep}/done", {}, self.t)
        self.assertTrue(d["next"] > past)

    # ---------- watch, books, bills ----------
    def test_business_watch_books_and_bills_ask_first(self):
        y = (plus.now_local().date() - dt.timedelta(days=10)).isoformat()
        self.add("invoices", {"customer": "Smith", "amount": 150, "due": y, "status": "Sent"})
        self.add("inventory", {"item": "Paint", "quantity": 1, "low_stock": 3})
        t = plus.now_local().date().isoformat()
        self.add("transactions", {"date": t, "kind": "Income", "amount": 100, "account": "George's Little Handy Books"})
        self.add("transactions", {"date": t, "kind": "Expense", "amount": 30, "category": "Ads", "account": "George's Little Handy Books"})
        bill = self.add("bills", {"payee": "Power Co", "amount": 80, "due": y, "account": "Personal"})
        s, d = req(self.base, "GET", "/api/watch", token=self.t)
        areas = [a["area"] for a in d["alerts"]]
        self.assertIn("Invoices", areas); self.assertIn("Inventory", areas); self.assertIn("Bills", areas)
        s, d = req(self.base, "GET", "/api/books", token=self.t)
        books = {a["account"]: a for a in d["accounts"]}
        self.assertEqual(books["George's Little Handy Books"]["profit"], 70)
        self.assertEqual(books["Personal"]["bills_due"], 80)
        # Never pays without George's yes
        s, d = req(self.base, "POST", f"/api/bills/{bill}/approve", {}, self.t)
        self.assertEqual(s, 400)
        s, d = req(self.base, "POST", f"/api/bills/{bill}/approve", {"approved": True}, self.t)
        self.assertEqual(s, 200); self.assertIn("no money moved", d["note"])
        s, d = req(self.base, "POST", f"/api/bills/{bill}/paid", {"approved": True}, self.t)
        self.assertEqual(d["status"], "Paid")
        s, d = req(self.base, "GET", "/api/books", token=self.t)
        self.assertEqual({a["account"]: a for a in d["accounts"]}["Personal"]["expenses"], 80)

    def test_briefing_works_with_nothing_connected(self):
        s, d = req(self.base, "GET", "/api/briefing", token=self.t)
        self.assertEqual(s, 200)
        self.assertIn("George", d["spoken"])
        self.assertTrue(any(x["title"] == "Business watch" for x in d["sections"]))

    # ---------- memory ----------
    def test_memory_unlimited_topics_pin_search_suggest(self):
        rid = self.add("learned", {"text": "Smith pays invoices late"})
        s, d = req(self.base, "GET", "/api/records?kind=learned", token=self.t)
        self.assertEqual([r for r in d["records"] if r["id"] == rid][0]["data"]["topic"], "Customers")
        s, d = req(self.base, "POST", "/api/memory/pin", {"id": rid, "pinned": True}, self.t)
        self.assertTrue(d["pinned"])
        s, d = req(self.base, "GET", "/api/memory/search?q=smith", token=self.t)
        self.assertEqual(d["notes"][0]["id"], rid)
        s, d = req(self.base, "POST", "/api/memory/suggest", {"text": "My truck is a 2019 F-150. I always open the shop at 8."}, self.t)
        self.assertIn("George's truck is a 2019 F-150", d["suggestions"])
        s, d = req(self.base, "POST", "/api/memory/suggest", {"text": "what is my truck?"}, self.t)
        self.assertEqual(d["suggestions"], [])
        with patch.object(server, "MAX_RECORDS_PER_USER", 1):
            self.add("learned", {"text": "Learned notes never hit the cap"})

    def test_smart_recall_keeps_pinned_and_relevant(self):
        notes = [{"id": str(i), "created": i, "data": {"text": f"filler note {i}"}} for i in range(200)]
        notes.append({"id": "p", "created": 1, "data": {"text": "Shop alarm code is in the safe", "pinned": True}})
        notes.append({"id": "r", "created": 2, "data": {"text": "Jones prefers plumbing jobs on Tuesday"}})
        got = [n["id"] for n in plus.relevant_notes(notes, "When does Jones want plumbing?", k=10)]
        self.assertIn("p", got); self.assertIn("r", got); self.assertEqual(len(got), 10)

    # ---------- All in One ----------
    def test_all_in_one_asks_every_brain_and_merges(self):
        calls = []

        def fake(p, system, messages):
            calls.append(p)
            return "MERGED" if "All in One" in system else f"answer from {p}"
        with patch.object(server, "call_ai", side_effect=fake), \
                patch.object(server, "ai_providers", return_value=["anthropic", "opus", "openai"]):
            s, d = req(self.base, "POST", "/api/ai/chat", {"provider": "allinone", "messages": [{"role": "assistant", "content": "hi"}, {"role": "user", "content": "best price?"}]}, self.t)
        self.assertEqual(s, 200, d)
        self.assertEqual(d["reply"], "MERGED")
        self.assertEqual(sorted(d["brains"]), sorted(plus.BRAIN_NAMES.values()))
        self.assertEqual(sorted(calls), ["anthropic", "anthropic", "openai", "opus"])
        s, d = req(self.base, "POST", "/api/ai/chat", {"provider": "allinone", "messages": [{"role": "user", "content": "x"}]}, self.t)
        self.assertEqual(s, 503)

    # ---------- connectors (no network) ----------
    def test_connectors_report_not_connected_and_gate_sending(self):
        s, d = req(self.base, "GET", "/api/plus/connectors", token=self.t)
        self.assertFalse(d["connectors"]["stripe"]); self.assertFalse(d["connectors"]["email"])
        s, d = req(self.base, "POST", "/api/connect/email/send", {"to": "a@b.com", "subject": "x", "body": "y"}, self.t)
        self.assertEqual(s, 400)   # no yes, no send
        s, d = req(self.base, "POST", "/api/connect/calendar/add", {"title": "x", "start": "2026-11-22T10:00"}, self.t)
        self.assertEqual(s, 400)
        s, d = req(self.base, "GET", "/api/connect/stripe", token=self.t)
        self.assertEqual(d, {"connected": False})

    def test_ics_parser_with_weekly_repeat(self):
        ics = ("BEGIN:VCALENDAR\r\nBEGIN:VEVENT\r\nDTSTART:20261123T160000Z\r\nSUMMARY:Team call\r\nRRULE:FREQ=WEEKLY\r\nEND:VEVENT\r\n"
               "BEGIN:VEVENT\r\nDTSTART;VALUE=DATE:20261124\r\nSUMMARY:Thanks\r\n giving prep\r\nEND:VEVENT\r\nEND:VCALENDAR\r\n")
        start = dt.datetime(2026, 11, 23, tzinfo=plus.tz())
        ev = plus.parse_ics(ics, start, start + dt.timedelta(days=14))
        self.assertEqual(sum(1 for e in ev if e["title"] == "Team call"), 2)
        self.assertIn("Thanksgiving prep", [e["title"] for e in ev])

    def test_stripe_summary_with_mock(self):
        def fake(path, params=None):
            now = int(__import__("time").time())
            return {"balance": {"available": [{"amount": 5000, "currency": "usd"}], "pending": []},
                    "charges": {"data": [{"amount": 3995, "status": "succeeded", "created": now, "refunded": False},
                                         {"amount": 3995, "status": "failed", "created": now}]},
                    "disputes": {"data": []}}[path]
        with patch.dict(os.environ, {"STRIPE_SECRET_KEY": "rk_test_x"}), patch.object(plus, "stripe_get", side_effect=fake):
            s = plus.stripe_summary()
        self.assertEqual(s["available"], 50.0); self.assertEqual(s["sales_24h"], 39.95); self.assertEqual(s["failed_7d"], 1)

    def test_backup_now_local_when_drive_not_connected(self):
        s, d = req(self.base, "POST", "/api/backup/now", {}, self.t)
        self.assertEqual(s, 200, d)
        self.assertTrue(d["local"]); self.assertFalse(d["drive"])
        files = list((Path(self.tmp.name) / "bk").glob("*.json"))
        self.assertTrue(files)
        self.assertIn("records", json.loads(files[0].read_text()))
        s, d = req(self.base, "GET", "/api/backup/status", token=self.t)
        self.assertEqual(d["last"]["local"], True)

    def test_receipt_needs_a_brain(self):
        s, d = req(self.base, "POST", "/api/receipt/read", {"image": "A" * 200, "media_type": "image/jpeg"}, self.t)
        self.assertEqual(s, 503)

    def test_new_files_served_and_secrets_not(self):
        s, d = req(self.base, "GET", "/plus.js")
        self.assertEqual(s, 200); self.assertIn("Hey Connie", d["text"])
        s, _ = req(self.base, "GET", "/connie_secrets.json")
        self.assertEqual(s, 404)
        s, _ = req(self.base, "GET", "/../connie_plus.py")
        self.assertEqual(s, 404)


if __name__ == "__main__":
    unittest.main()
