"""George's Assistant (Connie) v1.1 tests — personal copy of People's Bot v1.1 — run: python3 -m unittest discover -s tests -v
Uses only the standard library. Starts the real server on a local
ephemeral port with a temporary database. No network AI, no keys,
no live payments/phone/bank/tax are used or needed.
"""
import json
import os
import sys
import tempfile
import threading
import unittest
import urllib.error
import urllib.request
from pathlib import Path
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
import server  # noqa: E402


def req(base, method, path, body=None, token=None, extra_headers=None):
    headers = {"Content-Type": "application/json"}
    if token:
        headers["Authorization"] = "Bearer " + token
    if extra_headers:
        headers.update(extra_headers)
    r = urllib.request.Request(base + path,
                               data=json.dumps(body).encode() if body is not None else None,
                               headers=headers, method=method)
    try:
        with urllib.request.urlopen(r, timeout=5) as resp:
            raw = resp.read() or b"{}"
            try:
                return resp.status, json.loads(raw)
            except json.JSONDecodeError:
                return resp.status, {"text": raw.decode("utf-8", "replace")}
    except urllib.error.HTTPError as e:
        raw = e.read() or b"{}"
        try:
            return e.code, json.loads(raw)
        except json.JSONDecodeError:
            return e.code, {"text": raw.decode("utf-8", "replace")}


class ServerTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tmp = tempfile.TemporaryDirectory()
        cls.db = Path(cls.tmp.name) / "test.sqlite3"
        cls._patch = patch.object(server, "DB", cls.db)
        cls._patch.start()
        cls.srv = server.make_server("127.0.0.1", 0)
        cls.port = cls.srv.server_address[1]
        cls.base = f"http://127.0.0.1:{cls.port}"
        cls.thread = threading.Thread(target=cls.srv.serve_forever, daemon=True)
        cls.thread.start()
        cls.user = "alice_test"
        cls.pw = "correct-horse-battery-123"
        s, d = req(cls.base, "POST", "/api/register",
                   {"username": cls.user, "password": cls.pw})
        assert s == 200, d
        cls.token = d["token"]
        cls.recovery = d["recovery_code"]

    @classmethod
    def tearDownClass(cls):
        cls.srv.shutdown()
        cls._patch.stop()
        cls.tmp.cleanup()

    def test_health_and_status_are_honest(self):
        s, d = req(self.base, "GET", "/api/health")
        self.assertEqual(s, 200)
        self.assertEqual(d["status"], "ok")
        self.assertFalse(d["ai_enabled"])  # no key in this test env
        self.assertFalse(d["live_phone"])
        self.assertFalse(d["live_payments"])
        self.assertFalse(d["bank_feeds"])
        self.assertFalse(d["tax_filing"])
        s, d = req(self.base, "GET", "/api/status")
        self.assertEqual(s, 200)
        self.assertFalse(d["ai_enabled"])  # must match health when no key is set
        self.assertEqual(d["providers"], [])
        # Top brains are installed and reported: Opus 5.5 is the default, the only Claude.
        self.assertEqual(d["top_models"], {"anthropic": "claude-fable-5-2", "openai": "gpt-6.2-astra", "opus": "claude-opus-5-5"})
        self.assertEqual(d["default_provider"], "anthropic")

    def test_top_brains_are_installed(self):
        # Top 3 usable brains only (2026-11-18, George: "top three only,
        # just put them on"): Fable #1, GPT-6.2 Astra, Opus. Rank #2
        # Claude Mythos 5.2 is restricted (vetted organisations only)
        # and is NOT installed. Meta/Google/Grok were removed.
        self.assertEqual(server.TOP_AI_MODELS, {"anthropic": "claude-fable-5-2", "openai": "gpt-6.2-astra", "opus": "claude-opus-5-5"})
        self.assertEqual(server.DEFAULT_ANTHROPIC_MODEL, "claude-fable-5-2")
        self.assertEqual(server.DEFAULT_OPENAI_MODEL, "gpt-6.2-astra")
        self.assertEqual(server.DEFAULT_OPUS_MODEL, "claude-opus-5-5")
        self.assertEqual(server.ai_model("anthropic"), "claude-fable-5-2")
        self.assertEqual(server.ai_model("openai"), "gpt-6.2-astra")
        self.assertEqual(server.ai_model("opus"), "claude-opus-5-5")
        self.assertNotIn("meta", server.TOP_AI_MODELS)
        self.assertNotIn("google", server.TOP_AI_MODELS)
        self.assertNotIn("grok", server.TOP_AI_MODELS)
        with self.assertRaises(ValueError):
            server.ai_model("meta")
        with self.assertRaises(ValueError):
            server.ai_model("google")
        with self.assertRaises(ValueError):
            server.ai_model("grok")
        # A key alone counts as connected — no model env var needed.
        with patch.dict(os.environ, {"ANTHROPIC_API_KEY": "sk-test-key"}):
            # One Anthropic key serves both Claude brains: Fable and Opus.
            self.assertEqual(server.ai_providers(), ["anthropic", "opus"])
        with patch.dict(os.environ, {"OPENAI_API_KEY": "sk-test-key"}):
            self.assertEqual(server.ai_providers(), ["openai"])
        # call_ai builds the right request per provider (mocked transport).
        import urllib.request as _urlreq
        class _Resp:
            def __enter__(self): return self
            def __exit__(self, *a): return False
            def read(self): return b'{"choices": [{"message": {"content": "hello from GPT"}}]}'
        seen = {}
        def _fake_urlopen(req, timeout=60):
            seen["url"] = req.full_url
            seen["headers"] = dict(req.header_items())
            seen["body"] = req.data.decode()
            return _Resp()
        with patch.dict(os.environ, {"OPENAI_API_KEY": "openai-test-key"}):
            with patch.object(_urlreq, "urlopen", _fake_urlopen):
                self.assertEqual(server.call_ai("openai", "sys", [{"role": "user", "content": "hi"}]), "hello from GPT")
            self.assertIn("api.openai.com", seen["url"])
            self.assertIn("gpt-6.2-astra", seen["body"])
            self.assertEqual(seen["headers"].get("Authorization"), "Bearer openai-test-key")
        self.assertEqual(server.ai_providers(), [])

    def test_learned_notes_save_read_forget_and_refuse_unlawful(self):
        # A lawful thing to learn saves, reads back, and is per-user.
        s, d = req(self.base, "POST", "/api/records",
                   {"kind": "learned", "data": {"text": "Smith prefers morning appointments", "learned": "2026-11-16"}}, self.token)
        self.assertEqual(s, 201, d)
        rid = d["id"]
        s, d = req(self.base, "GET", "/api/records?kind=learned", token=self.token)
        self.assertTrue(any(r["id"] == rid and r["data"]["text"] == "Smith prefers morning appointments" for r in d["records"]))
        s, d2 = req(self.base, "POST", "/api/register",
                    {"username": "frank_test", "password": "correct-horse-battery-123"})
        s, d = req(self.base, "GET", "/api/records?kind=learned", token=d2["token"])
        self.assertFalse(any(r["id"] == rid for r in d["records"]))
        # Connie refuses to learn anything against the law, and says why.
        s, d = req(self.base, "POST", "/api/records",
                   {"kind": "learned", "data": {"text": "impersonate Smith and call his bank", "learned": "2026-11-16"}}, self.token)
        self.assertEqual(s, 400, d)
        self.assertIn("can't learn", d["error"].lower())
        s, d = req(self.base, "POST", "/api/records",
                   {"kind": "learned", "data": {"text": "clone a customer's voice without asking", "learned": "2026-11-16"}}, self.token)
        self.assertEqual(s, 400, d)
        # Forgetting removes the note.
        self.assertEqual(req(self.base, "DELETE", f"/api/records/{rid}", token=self.token)[0], 200)

    def test_connie_is_faster_than_peoples_bot(self):
        # Speed numbers George set 2026-11-16: double People's Bot's 30,
        # and no 5-hour session limit for George.
        self.assertEqual(server.AI_HOURLY_LIMIT, 60)
        self.assertEqual(server.SESSION_LIMIT, "none — no 5-hour session limit for George")
        s, d = req(self.base, "GET", "/api/health")
        self.assertEqual(d["ai_hourly_limit"], 60)
        self.assertIn("no 5-hour", d["session_limit"])
        self.assertIn("60", d["speed"])
        self.assertIn("double", d["speed"].lower())
        s, d = req(self.base, "GET", "/api/me", token=self.token)
        self.assertEqual(d["ai_hourly_limit"], 60)

    def test_fast_learn_and_open_knowledge_no_cap(self):
        # Connie's knowledge is open: learned_notes_text returns ALL
        # notes, not just 20 — seed 25 and read them all back.
        for i in range(25):
            s, d = req(self.base, "POST", "/api/records",
                       {"kind": "learned", "data": {"text": f"open knowledge note {i}", "learned": "2026-11-16"}}, self.token)
            self.assertEqual(s, 201, d)
        self.assertEqual(len(server.learned_notes_text(1)), 25)
        app_js = (Path(__file__).resolve().parent.parent / "web" / "app.js").read_text()
        self.assertIn("Fast Learn", app_js)
        self.assertIn("learn these:", app_js)
        self.assertIn("saveLearnedNotes", app_js)
        self.assertIn("Search what I learned", app_js)
        self.assertIn("no cap", app_js)
        self.assertIn("60 AI requests", app_js)
        self.assertIn("no 5-hour session limit", app_js)
        self.assertIn("Your upgrades are free", app_js)

    def test_monthly_upgrade_summary_approve_and_refuse(self):
        import time as _time
        # Two lawful notes learned this month (created = now).
        for text in ("monthly note one", "monthly note two"):
            s, d = req(self.base, "POST", "/api/records",
                       {"kind": "learned", "data": {"text": text, "learned": "2026-11-16"}}, self.token)
            self.assertEqual(s, 201, d)
        now = _time.gmtime()
        s, d = req(self.base, "GET", f"/api/monthly-upgrade?year={now.tm_year}&month={now.tm_mon}", token=self.token)
        self.assertEqual(s, 200, d)
        self.assertIn("upgrade", d["label"].lower())
        self.assertTrue(d["free"])
        self.assertIn("free", d["price"].lower())
        self.assertGreaterEqual(d["count"], 2)
        self.assertIn("monthly note one", d["items"])
        self.assertIn("monthly note two", d["items"])
        self.assertFalse(d["approved"])
        # Refuse: nothing is saved and nothing changes.
        s, d = req(self.base, "GET", "/api/records?kind=upgrades", token=self.token)
        before = len(d["records"])
        s, d = req(self.base, "POST", "/api/monthly-upgrade",
                   {"year": now.tm_year, "month": now.tm_mon, "approved": False}, self.token)
        self.assertEqual(s, 200, d)
        self.assertFalse(d["approved"])
        s, d = req(self.base, "GET", "/api/records?kind=upgrades", token=self.token)
        self.assertEqual(len(d["records"]), before)
        # Approve: one upgrade record is saved, and the summary says so.
        s, d = req(self.base, "POST", "/api/monthly-upgrade",
                   {"year": now.tm_year, "month": now.tm_mon, "approved": True}, self.token)
        self.assertEqual(s, 200, d)
        self.assertTrue(d["approved"])
        self.assertIn("free", d["note"].lower())
        s, d = req(self.base, "GET", f"/api/monthly-upgrade?year={now.tm_year}&month={now.tm_mon}", token=self.token)
        self.assertTrue(d["approved"])
        # Bad month/year is refused, and the endpoint needs sign-in.
        self.assertEqual(req(self.base, "GET", "/api/monthly-upgrade?year=2026&month=13", token=self.token)[0], 400)
        self.assertEqual(req(self.base, "GET", "/api/monthly-upgrade")[0], 401)
        # The upgrade panel and its button are in the app, with no price.
        app_js = (Path(__file__).resolve().parent.parent / "web" / "app.js").read_text()
        self.assertIn("Show my monthly upgrade", app_js)
        self.assertIn("Monthly upgrade — free for George", app_js)
        self.assertIn("does NOT retrain the model", app_js)

    def test_custom_connector_record_and_app_strings(self):
        # A custom connector saves as a record: name, what it does, and
        # the key/account NAME only — never a secret key in the record.
        s, d = req(self.base, "POST", "/api/records",
                   {"kind": "connectors", "data": {"key": "custom:123", "enabled": True,
                                                    "custom_name": "WhatsApp", "custom_what": "Message customers when an invoice is ready",
                                                    "custom_account": "my WhatsApp Business account", "approved": False}}, self.token)
        self.assertEqual(s, 201, d)
        rid = d["id"]
        s, d = req(self.base, "GET", "/api/records?kind=connectors", token=self.token)
        rec = [r for r in d["records"] if r["id"] == rid][0]
        self.assertEqual(rec["data"]["custom_name"], "WhatsApp")
        self.assertFalse(rec["data"]["approved"])
        self.assertNotIn("sk-", json.dumps(rec["data"]))
        app_js = (Path(__file__).resolve().parent.parent / "web" / "app.js").read_text()
        # Learn: auto-learn on (George's choice, 2026-11-25) — saves right
        # away without asking; law refusal cannot be switched off.
        # "I learned: ..." back, and Forget this / Forget everything.
        self.assertIn("Auto-learn is ON", app_js)
        self.assertIn("setAutoLearn", app_js)
        self.assertIn("I learned: ", app_js)
        self.assertIn("learn this:", app_js)
        self.assertIn("does NOT retrain the model", app_js)
        self.assertIn("Forget this", app_js)
        # Connect any connector: form names the account, keys stay on server.
        self.assertIn("Add any connector / plug in a new app", app_js)
        self.assertIn("Keys stay on the server, never in chat", app_js)
        self.assertIn("Plugged in — NOT connected", app_js)
        self.assertIn("Approve — I set the key/account on the server", app_js)
        # Law & safety knowledge, plain words, not legal advice.
        self.assertIn("Law &amp; safety — what I know", app_js)
        self.assertIn("General information only — NOT legal advice", app_js)
        self.assertIn("No single federal AI law", app_js)
        self.assertIn("HB 102", app_js)
        self.assertIn("Voice is the highest risk", app_js)
        self.assertIn("What Connie knows", app_js)
        self.assertIn("Claude Fable 5.2 (Anthropic) — #1, top level", app_js)
        self.assertIn("Claude Opus 5.5 (Anthropic) — top level", app_js)
        self.assertIn("GPT-6.2 Astra", app_js)
        self.assertNotIn("Muse Wonder", app_js)
        self.assertNotIn("Gemini 4 Carbon", app_js)
        self.assertNotIn("Grok 4.7", app_js)
        self.assertNotIn("gpt-6-astra", app_js)  # old GPT-6 Astra id, updated to gpt-6.2-astra
        self.assertNotIn("People's Bot", app_js)

    def test_auth_required(self):
        self.assertEqual(req(self.base, "GET", "/api/me")[0], 401)
        self.assertEqual(req(self.base, "GET", "/api/records")[0], 401)
        self.assertEqual(req(self.base, "POST", "/api/ai/chat",
                             {"messages": [{"role": "user", "content": "hi"}]})[0], 401)

    def test_ai_chat_fails_gracefully_with_no_key(self):
        s, d = req(self.base, "POST", "/api/ai/chat",
                   {"messages": [{"role": "user", "content": "hi"}]}, self.token)
        self.assertEqual(s, 503)
        self.assertIn("not connected", d["error"].lower())

    def test_ai_chat_provider_picker(self):
        # With providers mocked in, the picker honours the chosen one and
        # refuses one that is not connected (e.g. Meta is not wired in).
        with patch.object(server, "ai_providers", return_value=["openai", "anthropic"]), \
             patch.object(server, "call_ai", return_value="mock reply") as call:
            s, d = req(self.base, "POST", "/api/ai/chat",
                       {"messages": [{"role": "user", "content": "hi"}], "provider": "anthropic"}, self.token)
            self.assertEqual(s, 200, d)
            self.assertEqual(d["provider"], "anthropic")
            self.assertEqual(call.call_args[0][0], "anthropic")
            s, d = req(self.base, "POST", "/api/ai/chat",
                       {"messages": [{"role": "user", "content": "hi"}]}, self.token)
            self.assertEqual(d["provider"], "openai")  # default: first available
            s, d = req(self.base, "POST", "/api/ai/chat",
                       {"messages": [{"role": "user", "content": "hi"}], "provider": "meta"}, self.token)
            self.assertEqual(s, 503)
            self.assertIn("not connected", d["error"].lower())

    def test_crud_every_kind(self):
        for kind in sorted(server.KINDS):
            s, d = req(self.base, "POST", "/api/records",
                       {"kind": kind, "data": {"title": "test " + kind}}, self.token)
            self.assertEqual(s, 201, (kind, d))
            rid = d["id"]
            s, d = req(self.base, "PUT", f"/api/records/{rid}",
                       {"data": {"title": "edited " + kind}}, self.token)
            self.assertEqual(s, 200, (kind, d))
            s, d = req(self.base, "GET", f"/api/records?kind={kind}", token=self.token)
            self.assertTrue(any(r["id"] == rid and r["data"]["title"] == "edited " + kind
                                for r in d["records"]), kind)
            s, d = req(self.base, "DELETE", f"/api/records/{rid}", token=self.token)
            self.assertEqual(s, 200, (kind, d))

    def test_records_are_per_user(self):
        s, d = req(self.base, "POST", "/api/records",
                   {"kind": "notes", "data": {"title": "alice private"}}, self.token)
        rid = d["id"]
        s, d2 = req(self.base, "POST", "/api/register",
                    {"username": "bob_test", "password": "correct-horse-battery-123"})
        bob = d2["token"]
        s, d = req(self.base, "GET", "/api/records?kind=notes", token=bob)
        self.assertFalse(any(r["id"] == rid for r in d["records"]))
        self.assertEqual(req(self.base, "PUT", f"/api/records/{rid}",
                             {"data": {"title": "hijack"}}, bob)[0], 404)
        self.assertEqual(req(self.base, "DELETE", f"/api/records/{rid}", token=bob)[0], 404)

    def test_export_import_and_audit(self):
        req(self.base, "POST", "/api/records",
            {"kind": "notes", "data": {"title": "to export"}}, self.token)
        s, d = req(self.base, "GET", "/api/export", token=self.token)
        self.assertEqual(s, 200)
        self.assertTrue(any(r["data"].get("title") == "to export" for r in d["records"]))
        s, d = req(self.base, "POST", "/api/import",
                   {"records": [{"kind": "notes", "data": {"title": "imported"}}]}, self.token)
        self.assertEqual(s, 200)
        self.assertEqual(d["imported"], 1)
        s, d = req(self.base, "GET", "/api/audit", token=self.token)
        self.assertEqual(s, 200)
        self.assertTrue(len(d["audit"]) >= 3)

    def test_no_storefront_in_personal_copy(self):
        # Personal copy: no storefront, nothing published or sold.
        s, d = req(self.base, "GET", f"/api/store/{self.user}")
        self.assertEqual(s, 200)
        self.assertFalse(d["store_available"])
        self.assertEqual(d["products"], [])
        s, d = req(self.base, "GET", "/api/health")
        self.assertEqual(d["assistant"], "Connie")
        self.assertTrue(d["personal_copy"])
        self.assertIn("George only", d["permission_model"])
        # Connie's copy: girl's voice by default, ask-first research upgrade.
        app_js = (Path(__file__).resolve().parent.parent / "web" / "app.js").read_text()
        self.assertIn("ensureConnieGirlVoice", app_js)
        self.assertIn("Hello, George. I'm Connie", app_js)
        self.assertIn("Research to upgrade me", app_js)
        self.assertIn("$250", app_js)
        self.assertIn("No payment is live", app_js)
        self.assertNotIn("$15 a month", app_js)
        self.assertNotIn("$75 a month", app_js)
        self.assertNotIn("$150 a month", app_js)
        self.assertNotIn("$299", app_js)
        self.assertNotIn("People's Bot", app_js)

    def test_recovery_and_lockout(self):
        # Use a throwaway user: recovery deletes sessions and lockout
        # blocks the account, so the shared test user must not be touched.
        s, d = req(self.base, "POST", "/api/register",
                   {"username": "carol_test", "password": "correct-horse-battery-123"})
        self.assertEqual(s, 200, d)
        code = d["recovery_code"]
        s, d = req(self.base, "POST", "/api/recover",
                   {"username": "carol_test", "password": "",
                    "recovery_code": code, "new_password": "new-password-12345"})
        self.assertEqual(s, 200, d)
        s, d = req(self.base, "POST", "/api/login",
                   {"username": "carol_test", "password": "new-password-12345"})
        self.assertEqual(s, 200)
        # lockout: 5 wrong tries, then even the right password is refused
        for _ in range(5):
            self.assertEqual(req(self.base, "POST", "/api/login",
                                 {"username": "carol_test", "password": "wrong-password-123"})[0], 401)
        self.assertEqual(req(self.base, "POST", "/api/login",
                             {"username": "carol_test", "password": "new-password-12345"})[0], 429)

    def test_jobs_run_in_parallel_and_complete(self):
        # Seed records so the jobs have real figures to work from.
        req(self.base, "POST", "/api/records",
            {"kind": "inventory", "data": {"item": "Pipe", "quantity": 2, "low_stock": 5,
                                           "sell_price": "10"}}, self.token)
        req(self.base, "POST", "/api/records",
            {"kind": "invoices", "data": {"customer": "Smith", "amount": 150,
                                          "status": "Draft"}}, self.token)
        # Jobs need sign-in, and an unknown type is refused.
        self.assertEqual(req(self.base, "GET", "/api/jobs")[0], 401)
        self.assertEqual(req(self.base, "POST", "/api/jobs",
                             {"type": "send_invoice"}, self.token)[0], 400)
        # Start 3 jobs at once, in one request — they run together.
        s, d = req(self.base, "POST", "/api/jobs/batch",
                   {"types": ["inventory_check", "invoice_draft", "money_totals"]}, self.token)
        self.assertEqual(s, 201, d)
        self.assertEqual(len(d["jobs"]), 3)
        ids = [j["id"] for j in d["jobs"]]
        # Poll until all three finish (each takes ~0.4s of stepped work).
        done = {}
        for _ in range(50):
            s, d = req(self.base, "GET", "/api/jobs", token=self.token)
            self.assertEqual(s, 200, d)
            done = {j["id"]: j for j in d["jobs"] if j["id"] in ids}
            if len(done) == 3 and all(j["status"] == "done" for j in done.values()):
                break
            import time as _time
            _time.sleep(0.1)
        self.assertEqual(len(done), 3)
        self.assertTrue(all(j["status"] == "done" and j["progress"] == 100 for j in done.values()))
        # Results are real summaries from the seeded records, drafts only.
        inv = done[ids[0]]
        self.assertIn("Pipe", inv["result"])
        self.assertIn("150.00", done[ids[1]]["result"])
        self.assertTrue(done[ids[1]]["needs_approval"])
        # A single job can be cancelled, and jobs are per-user.
        s, d = req(self.base, "POST", "/api/jobs",
                   {"type": "usage_check"}, self.token)
        jid = d["job"]["id"]
        s, d = req(self.base, "POST", f"/api/jobs/{jid}/cancel", {}, self.token)
        self.assertEqual(s, 200, d)
        s, d2 = req(self.base, "POST", "/api/register",
                    {"username": "dave_test", "password": "correct-horse-battery-123"})
        s, d = req(self.base, "GET", "/api/jobs", token=d2["token"])
        self.assertEqual(d["jobs"], [])

    def test_voice_enrol_check_and_jobs_gate(self):
        feats = [round(i / 16, 3) for i in range(16)]
        far = [round(1 - i / 16, 3) for i in range(16)]
        # Voice needs sign-in, and enrolment needs consent.
        self.assertEqual(req(self.base, "GET", "/api/voice")[0], 401)
        self.assertEqual(req(self.base, "POST", "/api/voice/enroll",
                             {"name": "Alice", "phrase": "This is my bot",
                              "features": feats}, self.token)[0], 400)
        s, d = req(self.base, "GET", "/api/voice", token=self.token)
        self.assertEqual(d, {"enrolled": False})
        # Enrol with consent; no audio is stored, only the numbers.
        s, d = req(self.base, "POST", "/api/voice/enroll",
                   {"name": "Alice", "phrase": "This is my bot",
                    "features": feats, "consent": True}, self.token)
        self.assertEqual(s, 200, d)
        self.assertTrue(d["enrolled"])
        s, d = req(self.base, "GET", "/api/voice", token=self.token)
        self.assertTrue(d["enrolled"])
        self.assertEqual(d["name"], "Alice")
        self.assertNotIn("features", d)
        # A very different voice is not recognised and gets no token.
        s, d = req(self.base, "POST", "/api/voice/check",
                   {"features": far}, self.token)
        self.assertEqual(s, 200, d)
        self.assertFalse(d["recognised"])
        self.assertIsNone(d["voice_token"])
        # Jobs are now blocked without a recognised voice token.
        self.assertEqual(req(self.base, "POST", "/api/jobs",
                             {"type": "usage_check"}, self.token)[0], 403)
        # The enrolled voice is recognised, gets a token, and jobs run.
        s, d = req(self.base, "POST", "/api/voice/check",
                   {"features": feats}, self.token)
        self.assertTrue(d["recognised"], d)
        token = d["voice_token"]
        s, d = req(self.base, "POST", "/api/jobs",
                   {"type": "usage_check", "voice_token": token}, self.token)
        self.assertEqual(s, 201, d)
        # A different user has no voice enrolled and no gate.
        s, d2 = req(self.base, "POST", "/api/register",
                    {"username": "erin_test", "password": "correct-horse-battery-123"})
        s, d = req(self.base, "GET", "/api/voice", token=d2["token"])
        self.assertEqual(d, {"enrolled": False})
        self.assertEqual(req(self.base, "POST", "/api/jobs",
                             {"type": "usage_check"}, d2["token"])[0], 201)
        # Forget removes the voice — jobs work again with no gate.
        s, d = req(self.base, "DELETE", "/api/voice", token=self.token)
        self.assertEqual(s, 200, d)
        self.assertFalse(d["enrolled"])
        s, d = req(self.base, "GET", "/api/voice", token=self.token)
        self.assertEqual(d, {"enrolled": False})
        self.assertEqual(req(self.base, "POST", "/api/jobs",
                             {"type": "usage_check"}, self.token)[0], 201)

    def test_voice_choice_saved_in_settings_and_health_states_permission_model(self):
        # The speaking-voice choice is saved in the buyer's own
        # settings record on the server (the voice itself only exists
        # on their device), and health states the permission model.
        s, d = req(self.base, "GET", "/api/health")
        self.assertEqual(s, 200)
        self.assertIn("ask-first", d["permission_model"])
        self.assertIn("George only", d["permission_model"])
        s, d = req(self.base, "POST", "/api/records",
                   {"kind": "settings", "data": {"business": "Alice Test Shop",
                                                  "speaking_voice_uri": "Samantha",
                                                  "speaking_voice_name": "Samantha"}}, self.token)
        self.assertEqual(s, 201, d)
        rid = d["id"]
        s, d = req(self.base, "GET", "/api/records?kind=settings", token=self.token)
        self.assertTrue(any(r["id"] == rid and r["data"].get("speaking_voice_name") == "Samantha"
                            for r in d["records"]))

    def test_hosting_ready_binding(self):
        # Hosting (George approved 2026-11-16): when a host sets PORT
        # and no HOST is set, the server binds 0.0.0.0 so the host's
        # proxy can reach it. Locally, with no PORT and no HOST, it
        # still binds 127.0.0.1 only. An explicit HOST always wins.
        with patch.dict(os.environ, {}, clear=False):
            os.environ.pop("HOST", None)
            os.environ.pop("PORT", None)
            srv = server.make_server()
            self.assertEqual(srv.server_address[0], "127.0.0.1")
            srv.server_close()
            os.environ["PORT"] = "19999"
            srv = server.make_server()
            self.assertEqual(srv.server_address[0], "0.0.0.0")
            self.assertEqual(srv.server_address[1], 19999)
            srv.server_close()
            os.environ["HOST"] = "127.0.0.1"
            srv = server.make_server()
            self.assertEqual(srv.server_address[0], "127.0.0.1")
            srv.server_close()
            del os.environ["PORT"]
            del os.environ["HOST"]

    def _set_passcode(self, code="correct-horse-123"):
        return req(self.base, "POST", "/api/passcode/set",
                   {"passcode": code, "password": self.pw}, self.token)

    def _voice_token(self, feats):
        s, d = req(self.base, "POST", "/api/voice/check",
                   {"features": feats}, self.token)
        self.assertTrue(d.get("recognised"), d)
        return d["voice_token"]

    def test_passcode_two_step_voice_then_passcode(self):
        # Two-step, in order: voice first, then passcode. Neither
        # alone opens Connie once both are set.
        feats = [round(i / 16, 3) for i in range(16)]
        try:
            s, d = req(self.base, "POST", "/api/voice/enroll",
                       {"name": "Alice", "phrase": "This is my bot",
                        "features": feats, "consent": True}, self.token)
            self.assertEqual(s, 200, d)
            s, d = self._set_passcode()
            self.assertEqual(s, 200, d)
            self.assertTrue(d["set"])
            # Voice alone: no. Passcode alone: no. Both: yes.
            self.assertEqual(req(self.base, "POST", "/api/jobs",
                                 {"type": "usage_check"}, self.token)[0], 403)
            vt = self._voice_token(feats)
            self.assertEqual(req(self.base, "POST", "/api/jobs",
                                 {"type": "usage_check", "voice_token": vt}, self.token)[0], 403)
            s, d = req(self.base, "POST", "/api/passcode/check",
                       {"voice_token": vt, "passcode": "correct-horse-123"}, self.token)
            self.assertEqual(s, 200, d)
            pt = d["passcode_token"]
            s, d = req(self.base, "POST", "/api/jobs",
                       {"type": "usage_check", "voice_token": vt, "passcode_token": pt}, self.token)
            self.assertEqual(s, 201, d)
            # Passcode check without a recognised voice first: refused.
            self.assertEqual(req(self.base, "POST", "/api/passcode/check",
                                 {"passcode": "correct-horse-123"}, self.token)[0], 403)
            # Download my stuff needs both tokens too; without them 403.
            self.assertEqual(req(self.base, "GET", "/api/export", token=self.token)[0], 403)
            s, d = req(self.base, "GET", f"/api/export?voice_token={vt}&passcode_token={pt}", token=self.token)
            self.assertEqual(s, 200, d)
            self.assertIn("records", d)
        finally:
            # Clean up so later tests are not gated by this passcode.
            req(self.base, "POST", "/api/passcode/remove",
                {"password": self.pw}, self.token)
            req(self.base, "DELETE", "/api/voice", token=self.token)

    def test_passcode_short_codes_refused_and_hash_only(self):
        # No code is unbreakable: a 4-digit code has only 10,000
        # combinations, so short codes are refused, and the stored
        # value is a salted hash — never the passcode itself.
        try:
            for bad in ("1234", "1234567", "password", "12345678"):
                s, d = self._set_passcode(bad)
                self.assertEqual(s, 400, (bad, d))
            s, d = self._set_passcode("correct-horse-123")
            self.assertEqual(s, 200, d)
            with server.connect() as c:
                row = c.execute("SELECT salt,hash FROM passcodes WHERE owner=?",
                                (1,)).fetchone()
            # The test user is the first account created (id 1).
            self.assertIsNotNone(row)
            self.assertNotIn("correct-horse-123", row[1])
            self.assertNotEqual(row[1], "correct-horse-123")
            # Setting it needs the account password — a wrong one fails.
            s, d = req(self.base, "POST", "/api/passcode/set",
                       {"passcode": "another-one-456", "password": "wrong-password-123"}, self.token)
            self.assertEqual(s, 403, d)
        finally:
            req(self.base, "POST", "/api/passcode/remove",
                {"password": self.pw}, self.token)

    def test_passcode_lockout_after_three_wrong_tries(self):
        feats = [round(i / 16, 3) for i in range(16)]
        try:
            req(self.base, "POST", "/api/voice/enroll",
                {"name": "Alice", "phrase": "This is my bot",
                 "features": feats, "consent": True}, self.token)
            self.assertEqual(self._set_passcode()[0], 200)
            vt = self._voice_token(feats)
            # Two wrong tries: 401 with tries left. Third: locked (429).
            self.assertEqual(req(self.base, "POST", "/api/passcode/check",
                                 {"voice_token": vt, "passcode": "wrong-code-111"}, self.token)[0], 401)
            self.assertEqual(req(self.base, "POST", "/api/passcode/check",
                                 {"voice_token": vt, "passcode": "wrong-code-222"}, self.token)[0], 401)
            s, d = req(self.base, "POST", "/api/passcode/check",
                       {"voice_token": vt, "passcode": "wrong-code-333"}, self.token)
            self.assertEqual(s, 429, d)
            # Even the right code is refused while locked.
            self.assertEqual(req(self.base, "POST", "/api/passcode/check",
                                 {"voice_token": vt, "passcode": "correct-horse-123"}, self.token)[0], 429)
            s, d = req(self.base, "GET", "/api/passcode/status", token=self.token)
            self.assertTrue(d["locked"])
            self.assertTrue(d["set"])
        finally:
            req(self.base, "POST", "/api/passcode/remove",
                {"password": self.pw}, self.token)
            req(self.base, "DELETE", "/api/voice", token=self.token)

    def test_unauthenticated_writes_refused(self):
        # Security blanket: no write without a signed-in owner session.
        self.assertEqual(req(self.base, "POST", "/api/records",
                             {"kind": "notes", "data": {"title": "x"}})[0], 401)
        self.assertEqual(req(self.base, "PUT", "/api/records/abc",
                             {"data": {}})[0], 401)
        self.assertEqual(req(self.base, "DELETE", "/api/records/abc")[0], 401)
        self.assertEqual(req(self.base, "POST", "/api/voice/check",
                             {"features": [0.5] * 16})[0], 401)
        self.assertEqual(req(self.base, "POST", "/api/passcode/set",
                             {"passcode": "correct-horse-123", "password": "x"})[0], 401)
        self.assertEqual(req(self.base, "POST", "/api/import",
                             {"records": []})[0], 401)
        self.assertEqual(req(self.base, "GET", "/api/export")[0], 401)

    def test_https_only_mode(self):
        # HTTPS-only when hosted: plain HTTP is refused for anything
        # carrying data, but the health check stays open so the host
        # can check the service, and HTTPS (via the host's proxy
        # header) is allowed through.
        old = server.HTTPS_ONLY
        server.HTTPS_ONLY = True
        try:
            self.assertEqual(req(self.base, "GET", "/api/health")[0], 200)
            self.assertEqual(req(self.base, "GET", "/app.html")[0], 426)
            s, _ = req(self.base, "GET", "/app.html",
                       extra_headers={"X-Forwarded-Proto": "https"})
            self.assertEqual(s, 200)
        finally:
            server.HTTPS_ONLY = old

    def test_static_pages(self):
        for path in ("/", "/app.html", "/app.css", "/app.js"):
            s, _ = req(self.base, "GET", path)
            self.assertEqual(s, 200, path)
        self.assertEqual(req(self.base, "GET", "/nope.html")[0], 404)
        self.assertEqual(req(self.base, "GET", "/store.html")[0], 404)  # no storefront in the personal copy
        self.assertEqual(req(self.base, "GET", "/../server.py")[0], 404)
        self.assertEqual(req(self.base, "GET", "/api/nope", token=self.token)[0], 404)


if __name__ == "__main__":
    unittest.main()
