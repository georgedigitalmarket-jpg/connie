# Copyright Registration — Ready to File (NOT filed yet)
## George's Assistant — Connie

Owner and author: **George Wederski**

© 2026 George Wederski. All rights reserved. No part of this book/app may be copied, reproduced, or shared without written permission from George Wederski.

**Status: PREPARED ONLY — nothing has been submitted, nothing has been paid, and no personal or bank details have been entered anywhere. Only George can submit this. Remy cannot file it for him.**

## Please read this first — the © notice is NOT the same as registering

Putting the © notice on the app is a good start — it tells everyone
the app belongs to George. But **the notice alone is NOT registration.**

- The © notice = a warning sign. It says "this is mine."
- **Registration with the US Copyright Office = the legal paperwork
  that gives George the right to sue someone in court if they copy
  the app**, and to claim proper damages for the copying.
- Without registration, George still owns the app (he made it), but
  he cannot take a copier to federal court until he registers.
- **Only George can submit the registration.** Remy cannot file it,
  sign it, or pay for it for him — the Copyright Office needs
  George himself to create the account, sign, and pay.

## What is being registered

- **Work:** George's Assistant — Connie (a personal assistant app,
  version 1.1). The app code, screens, and text George owns.
- **Author / owner:** George Wederski.
- **Year:** 2026.

## What it costs and how long it takes

- **Single application: $45** — for one work by one author (this app,
  by George alone).
- **Standard application: $65** — use this one only if the Single
  form does not fit (for example, if there is more than one author).
- **Time:** about **3.4 months** on average for the Copyright Office
  to finish processing it.
- **You can sell first and register later.** Selling the app does
  not stop George from registering it, and registering does not
  have to happen before a sale. But registering sooner is better:
  if someone copies the app before it is registered, George's
  options in court are weaker.

## What George needs to do himself — step by step

Do this on his own computer, at **copyright.gov/eCO**
(the US Copyright Office's online system, called eCO).

1. **Go to copyright.gov/eCO** and click to create a new account.
   He will pick a username and password and give an email address.
   This is George's own account — do not share the password.
2. **Start a new claim.** Pick the kind of work that fits best
   (for a computer program/app, the system will guide him to the
   right category — follow what eCO asks).
3. **Fill in the details:**
   - Title of the work: **George's Assistant — Connie**
   - Author: **George Wederski**
   - Year created: **2026**
   - Who owns it: **George Wederski**
   Answer only what is asked. Do not add anyone else as an author
   unless they truly helped write the app.
4. **Upload a copy of the work.** eCO will ask for a copy to be
   deposited. Use the zip file in this folder:
   `Georges_Assistant_Connie_2026-11-17.zip`
   (the finished build of the app). Upload that file when eCO asks
   for it.
5. **Pay the fee** — $45 (Single) or $65 (Standard) — by card,
   straight on the Copyright Office site. George pays this
   himself; nobody else should be given his card details.
6. **Sign and submit.** eCO will ask George to certify (sign) that
   the details are true. Only George signs it. Then submit.
7. **Save the receipt and the case number** eCO gives him. Keep
   them somewhere safe — that number is how he checks on the
   registration while it is being processed (about 3.4 months).
8. **Wait for the certificate.** The Copyright Office will send the
   registration certificate when it is done. Keep it with his
   other business papers.

## What George needs to have ready before he starts

- This folder, with the finished zip file
  (`Georges_Assistant_Connie_2026-11-17.zip`).
- An email address he can receive mail at.
- A payment card for the $45 (or $65) fee.
- About 30 minutes of quiet time to fill in the form.

## What Remy did NOT do (and will not do without George saying so)

- Did NOT submit anything to the Copyright Office.
- Did NOT pay anything.
- Did NOT enter George's personal details, address, date of birth,
  or bank/card details anywhere.
- Did NOT create an eCO account for George.

## Quick summary

| Step | Who does it |
|---|---|
| © notice added to the app, README, and status file | Done by Remy — 2026-11-17 |
| Register at copyright.gov/eCO ($45 Single / $65 Standard) | **George only — not done yet** |
| Upload the app zip as the copy | George, when he files |
| Sign and pay | George only |
| Wait ~3.4 months for the certificate | Copyright Office |

**Bottom line: the © notice is on the app now. Registration is the
separate legal step, and only George can do it — when he is ready,
follow the steps above at copyright.gov/eCO.**

---

# FILLED-IN DRAFT — what to type into copyright.gov/eCO, screen by screen

**This is a DRAFT only, written here so George can copy the answers
into the form. Nothing here has been typed into copyright.gov, nothing
has been submitted, and nothing has been paid.**

How to use it: open copyright.gov/eCO on his own computer, go through
the screens in order below, and type in the answers given. Anywhere it
says **[George fills this in himself]**, leave it blank here on purpose
— Remy does not know it, or must not enter it. Do not guess at those.

## Screen 1 — Log in or create an eCO account

- eCO username: **[George fills this in himself]** (pick one and
  remember it)
- eCO password: **[George fills this in himself]**
- Email address for the account: **[George fills this in himself]**
- Mailing address: **[George fills this in himself]**
- Phone number: **[George fills this in himself]**

This is George's own Copyright Office account. Do not share the
password with anyone.

## Screen 2 — Start a new claim: Single ($45) or Standard ($65)

eCO will ask which kind of application. Pick **Single Application —
$45**, because all of these are true for this app:

- One work only (this one app).
- One author only (George Wederski, alone).
- George is the only person claiming the copyright.
- The app was not made for hire for someone else.

Pick **Standard Application — $65** only if one of those stops being
true — for example, if someone else also wrote part of the app and
needs to be listed as an author. If in doubt, George should pick
Standard, because it covers more situations; it just costs $20 more.

## Screen 3 — Type of work

- Type of work: **Computer program** (the Copyright Office registers
  computer programs as a **literary work** — if eCO shows a list,
  pick the one that says computer program / literary work).

## Screen 4 — Title of the work

- Title: **George's Assistant — Connie**
- Nothing else in the title boxes. Do not add a subtitle.

## Screen 5 — Author

- Author name: **George Wederski**
- What the author created: **entire work** (the whole app — the
  code, the screens, and the words in it)
- Year of creation: **2026**
- Author's citizenship / where the author lives:
  **[George fills this in himself]**
  (eCO asks this — it is just the country where George is a citizen
  or lives. Remy is not entering it here.)
- Date of birth: **[George fills this in himself]** (only if eCO asks
  for it on this screen)

Do not add any other author. Nobody else wrote this app.

## Screen 6 — Publication: is the app published?

- Publication status: **Unpublished**
- Why: this is George's own personal copy. It has **not** been sold,
  given out, or put on the internet for the public. It runs only on
  George's own computer.
- Date of first publication: leave blank — there has not been one.
  (If George later sells a version of it, that does not undo this
  registration, and he can register the new version separately.)

## Screen 7 — Copyright claimant (who owns it)

- Claimant name: **George Wederski**
- Claimant address: **[George fills this in himself]**

The claimant is the owner. That is George, and only George.

## Screen 8 — What the work is (description, in plain words)

If eCO asks for a short description of the work, type this:

> "George's Assistant — Connie is a personal assistant app made for
> George Wederski alone. Connie is the assistant inside the app and
> speaks in a girl's voice. The app has ten screens: Assistant
> (Connie), Front Desk, Invoices, Money, Inventory, Tasks, Products
> & Marketing (George's own drafts only), Personal, Paper Trading
> (paper only, no real money), Settings, and Integrations. George
> signs in, and Connie asks him first before she looks at his
> records or does any job. She only runs jobs for George's enrolled
> voice. The app runs on George's own computer. It has no live
> payments, no AI key, no phone provider, and it is not for sale."

## Screen 9 — Anything already published or owned by someone else?

eCO may ask whether the work contains material that was already
published or written by someone else, and what is new in this
version.

- **George answers this screen himself.** Remy is not guessing at
  it, because this copy was built from the People's Bot v1.1 base
  that was also made for George, then renamed and changed for him
  alone. If eCO asks, George should say, in his own words, that
  the app was built for him and the Connie version is his personal
  copy. If he is unsure what to write here, he should leave the
  claim as it stands and ask the Copyright Office's help line
  rather than guessing.

## Screen 10 — Upload a copy of the work (the deposit)

- File to upload: **`Georges_Assistant_Connie_2026-11-17.zip`**
  (the finished build of the app, in this same folder).
- Upload that zip file when eCO asks for the copy. Do not upload
  any other file, and do not upload anything with passwords,
  recovery codes, or bank details in it — the zip has none of those.

## Screen 11 — Check everything, then certify (sign)

- Read every screen back once before submitting. Check the title
  is **George's Assistant — Connie**, the author is
  **George Wederski**, and the year is **2026**.
- Certification / signature: **[George fills this in himself — only
  George signs it]**. This is George swearing the details are true.
  Remy cannot sign it for him.

## Screen 12 — Pay

- Fee: **$45** (Single) or **$65** (Standard) — whichever
  application George picked on Screen 2.
- Payment card: **[George fills this in himself]** — typed straight
  into the Copyright Office site, by George himself. Nobody else
  should be given his card details, and they are not written
  anywhere in this file.
- After paying, **save the receipt and the case number** eCO shows.
  That number is how George checks on the registration during the
  ~3.4 months it takes to process.

## Blanks George still has to fill in himself — the full list

1. eCO account username and password
2. Email address for the eCO account
3. Mailing address (for the account and the claimant)
4. Phone number
5. Date of birth (only if eCO asks for it)
6. Author's citizenship / place of domicile
7. The "already published / someone else's material" screen (Screen 9)
   — George answers it in his own words
8. Payment card details ($45 or $65)
9. His signature / certification on the form
10. The receipt and case number after he files (he gets these from
    eCO — they do not exist yet)

## Everything already filled in above — the quick copy list

| Question on the form | Answer to type in |
|---|---|
| Title of the work | George's Assistant — Connie |
| Author | George Wederski |
| Year of creation | 2026 |
| Type of work | Computer program (literary work) |
| What the author created | Entire work |
| Publication status | Unpublished (personal copy, not for sale) |
| Copyright claimant | George Wederski |
| Application | Single — $45 (or Standard — $65 if it does not fit) |
| File to upload | Georges_Assistant_Connie_2026-11-17.zip |
| Description | See Screen 8 above |

**Still true: this draft is NOT a filing. Nothing has been submitted,
nothing has been paid, and George's personal and bank details have
not been entered anywhere. Only George can submit it, at
copyright.gov/eCO, when he is ready.**
